<?php

abstract class Plugin_openXDeliveryLogLwes_CustomEvent 
{
	public static $sanityCheckESF = false;
	
	/**
     * Supported LWES data types
     */
    const DATA_TYPE_U_INT_16 = 'U_INT_16';
    const DATA_TYPE_INT_16   = 'INT_16';
    const DATA_TYPE_U_INT_32 = 'U_INT_32';
    const DATA_TYPE_INT_32   = 'INT_32';
    const DATA_TYPE_STRING   = 'STRING';
    const DATA_TYPE_IP_ADDR  = 'IP_ADDR';
    const DATA_TYPE_BOOLEAN  = 'BOOLEAN';

    protected $eventType = null;

    /**
     * Data which will be used to build an Event object (using
     * the data formatiing defined in getDataDefinition())
     * @var array Key => Value
     */
    public $dataValues = array();

    protected $esfFilePath = null;
    
    public static function &factory($eventType)
    {
        $className = 'Lwes_Event_'.$eventType;
        if (!class_exists($className)) {
        	$filename = BS_PATH. '/CustomEvent/'.$eventType.'.php';
            if (!is_file($filename)) {
                throw new Exception("Event '{$eventType}' not implemented");
            }
            require $filename;
        }
        if (!class_exists($className)) {
            throw new Exception("EventType class name '$className' not implemented");
        }
        $oEvent = new $className();
        return $oEvent;
    }

    abstract function setData($source, $data = array());
    /**
     * @return array ( field name => array(data type, size) )
     */
	abstract function getDataDefinition();
	
    function getEventObject()
    {
        $oEvent = $this->getEvent();
        foreach ($this->getDataDefinition() as $name => $aType) {
            if (isset($this->dataValues[$name])) {
                $this->addToEvent($oEvent, $name, $this->dataValues[$name], $aType[0], isset($aType[1]) ? $aType[1] : null);
            }
        }
        return $oEvent;
    }

    function getEvent()
    {
		if(self::$sanityCheckESF) {
	        return new Lwes_EventTypeDb($this->eventType, $this->getEsfFilePath());
		}
    	return new Lwes_Event($this->eventType);
    }

    function setEsfFilePath($path) {
    	$this->esfFilePath = $path;
    }
    
    function getEsfFilePath() {
    	if(is_null($this->esfFilePath)) {
    		throw new Exception("the ESF definition file must be set in order to sanity check events against the .esf definition file. @see setEsfFilePath()");
    	}
    	return $this->esfFilePath;
    }
    
    function addToEvent($oEvent, $key, $dataValue, $dataType, $dataLength = null)
    {
        // Truncate strings
        if ($dataType == self::DATA_TYPE_STRING) {
            if ($dataLength < 1) {
                throw new Exception('Invalid data length for key: '.$key);
            }
            $dataValue = substr($dataValue, 0, $dataLength);
        }

        $addMethod = 'set'.$dataType;
        if (method_exists($oEvent, $addMethod)) {
            $ret = $oEvent->$addMethod($key, $dataValue, $dataLength);
            if ($ret < 0) {
                throw new Exception('Error seeting attribute, name: '.$key.', error type: '
                    . $oEvent->getErrorMessage($ret));
            }
        } else {
            throw new Exception('Set method not defined for data type: '.$dataType);
        }
    }

    function getParamByName($aParams, $name, $default = '')
    {
        return isset($aParams[$name]) ? $aParams[$name] : $default;
    }
}