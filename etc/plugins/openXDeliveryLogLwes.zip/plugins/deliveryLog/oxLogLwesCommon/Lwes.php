<?php

require_once BS_PATH . '/lib/Lwes/Emitter.php';
require_once BS_PATH . '/lib/Lwes/EventTypeDb.php';
require_once BS_PATH . '/CustomEvent.php';

class Plugin_oxDeliveryLogLwes_Lwes
{
    private $extensionAvailable = true;
    private $aConf;
    protected $aEmitters;
    static protected $dnsCache = array();

    public function resolveHost ($hostOrIP) {
        // locally cache the DNS lookup, which can help with performance 
        // when multiple events are sent in the same HTTP request (eg. Response and BannerList)
        if(!isset(self::$dnsCache[$hostOrIP])) { 
            // if $host is a hostname string...
            if(long2ip(ip2long($hostOrIP)) != $hostOrIP) {
                // we query the actual IP, as the LWES C extension expects IPs for journallers
                // echo "DNS query...";
                self::$dnsCache[$hostOrIP] = gethostbyname($hostOrIP);
            } else {
                self::$dnsCache[$hostOrIP] = $hostOrIP;
            }
        }
        return self::$dnsCache[$hostOrIP]; 
    }
    
    public function __construct($aConf)
    {
        $this->aConf = $aConf;
        // Here we expect to be passed a comma separated list of hostnames
        //
        // example: host1, host2
        //
        $aHosts = array();
        foreach (explode(',', $aConf['hosts']) as $host)
        {
            $host = $this->resolveHost(trim($host));
            $aHost = array(
                    'host' => $host,
                    'port' => $this->aConf['port']
                    );
            $aHosts[] = $aHost;
        }
        
        foreach (explode(',', $aConf['bannerListHosts']) as $host)
        {
            $host = $this->resolveHost(trim($host));
            $port = isset ($this->aConf['bannerListPort'])
                ? $this->aConf['bannerListPort']
                : $this->aConf['port'];
            $aHost = array(
                    'host' => $host,
                    'port' => $port,
                    'event' => 'BannerList',
                    );
            $aHosts[] = $aHost;
        }
        
        try {
	        $this->aEmitters = array();
	        $this->setUp($aHosts);
        } catch (Exception $e) {
            $this->extensionAvailable = false;
        }
        
        if(isset($this->aConf['sanity_check_esf'])
        	&& $this->aConf['sanity_check_esf']) {
        	Plugin_openXDeliveryLogLwes_CustomEvent::$sanityCheckESF = true;
        }
    }

    public function setEsfFilePath($path) {
    	$this->esfFilePath = $path;
    }
    
    public function dispatch($eventTypeName, $source, $aData = array())
    {
        if ($this->extensionAvailable) {
	            $eventType = Plugin_openXDeliveryLogLwes_CustomEvent::factory($eventTypeName);
	            $eventType->setEsfFilePath($this->esfFilePath);
	            $eventType->setData($source, $aData);
	            $this->emit($eventType->getEventObject(), $eventTypeName);
        }
    }

    public function setUp($aHosts)
    {
        foreach ($aHosts as $aHost) {
          $evt = isset ($aHost['event']) ? $aHost['event'] : 'default';
          $this->aEmitters[$evt][] = $this->createEmitter($aHost['host'], $aHost['port']);
        }
    }

    public function createEmitter($host, $port)
    {
        return new Lwes_Emitter($host, $port);
    }

    public function emit($aEvent, $eventTypeName = 'default')
    {
      if (!isset ($this->aEmitters[$eventTypeName]))
      {
        $eventTypeName = 'default';
        if (!isset ($this->aEmitters['default']))
        {
          return;
        }
      }

      // hack.  if the eventTypeName is BannerList, we'll pick only one of the
      // hosts from the list and emit to it.
      if ($eventTypeName == 'BannerList')
      {
        $num_emitters = count ($this->aEmitters[$eventTypeName]);
        $e_idx = mt_rand (0,$num_emitters-1);
        $emitter = $this->aEmitters[$eventTypeName][$e_idx];
        $emitter->emit($aEvent);
      }
      else
      {
          // if a value for hostsEmitCount is specified, we will only emit to
          // that many emitters out of the set of available emitters.
          // An emitter will be picked at random, and the subsequent emitters
          // in the list will be used if emitting to more than one is required.
          $n = $num_emitters = count ($this->aEmitters[$eventTypeName]);
          $e_idx = 0;
          if (isset($this->aConf['hostsEmitCount'])) {
              $n = $this->aConf['hostsEmitCount'];
              if ($n > 0 && $n < $num_emitters) {
                  $e_idx = mt_rand (0,$num_emitters-1);
              } else {
                  $n = $num_emitters;
              }
          }
          while ($n--) {
              $emitter = $this->aEmitters[$eventTypeName][($e_idx++) % $num_emitters];
              $emitter->emit($aEvent);
          }
      }
    }

}

?>
