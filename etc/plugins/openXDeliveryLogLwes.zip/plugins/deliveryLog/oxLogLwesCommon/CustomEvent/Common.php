<?php
/**
- is banner id AND ad id AND creative id all the same thing? If not, can you please explain? :) If yes, then the code is very confusing.
- OXLIA	GET parameter in the impression request (lg.php?...) is defined as "Used to track the last time an ad was viewed" in the file etc/dist.conf.php. it seems value is always 1 on my install, not sure if the comment is wrong, or? (same question for OXLCA)

i.	"x-moz: prefetch" HTTP header (to assess the self-announced Prefetch activity). Although this field is typically not captured, it is needed to verify a very specific requirement.
d)	Self-announced prefetch activity (referred to in the click measurement guidelines)

*/


require_once BS_PATH . '/lib/UserAgentParser/UserAgentParser.php';

abstract class Lwes_Event_Common extends Plugin_openXDeliveryLogLwes_CustomEvent
{
	const EVENT_DEFINITION_SVN_REVISION = 43692;
	
        function getCoreDataDefinition() {
            return array(
                    'e_version' 			=> array(self::DATA_TYPE_INT_32),
                    'e_id'      			=> array(self::DATA_TYPE_STRING, 100),
                    'e_hox_trax_id'			=> array(self::DATA_TYPE_STRING, 100),
                    'e_hox_trax_time'		=> array(self::DATA_TYPE_INT_32),
                    'x_platform_id'			=> array(self::DATA_TYPE_STRING, 100),
                    );
        }

	function getDataDefinition() {
	    if(isset($GLOBALS['_MAX']['CONF']['oxLogLwes']['maximumLengthCookieField'])) {
	        $maximumLengthCookieField = $GLOBALS['_MAX']['CONF']['oxLogLwes']['maximumLengthCookieField'];
	    }
	    if(empty($maximumLengthCookieField)) {
	        $maximumLengthCookieField = 4096;
	    }
	    
            return array_merge(
                    $this->getCoreDataDefinition (),
                    array(
                        'x_host'			    => array(self::DATA_TYPE_STRING, 200),
                        'x_response_ms'			=> array(self::DATA_TYPE_U_INT_32),

                        'x_ip_blst_g'			=> array(self::DATA_TYPE_BOOLEAN),
                        'x_ip_blst_p'			=> array(self::DATA_TYPE_BOOLEAN),
                        'x_ua_blst'			    => array(self::DATA_TYPE_BOOLEAN),
                        'x_ua_no_wlst'			=> array(self::DATA_TYPE_BOOLEAN),

                        'u_viewer_id'			=> array(self::DATA_TYPE_STRING, 100),
                        'u_new_viewer_id'		=> array(self::DATA_TYPE_BOOLEAN),
                        'u_ip_addr' 			=> array(self::DATA_TYPE_IP_ADDR),
                        'u_header_ck'           => array(self::DATA_TYPE_STRING, $maximumLengthCookieField),
                        'u_header_ua'           => array(self::DATA_TYPE_STRING, 1024),
                        'u_header_lang'         => array(self::DATA_TYPE_STRING, 100),
                        'u_header_prefetch'		=> array(self::DATA_TYPE_BOOLEAN),
                        'u_browser_name'		=> array(self::DATA_TYPE_STRING, 10),
                        'u_browser_vers'		=> array(self::DATA_TYPE_STRING, 15),
                        'u_os'					=> array(self::DATA_TYPE_STRING, 5),

                        'u_page_url'			=> array(self::DATA_TYPE_STRING, 2048),
                        'u_ox_url'				=> array(self::DATA_TYPE_STRING, 2048),
                        )
                            );
	}
	
    function setCoreData($source, $data = array())
    {
    	$data['e_id'] = $this->getEventId();
        $data['e_version'] = self::EVENT_DEFINITION_SVN_REVISION;
        $data['x_platform_id'] = $GLOBALS['_MAX']['CONF']['oxLogLwes']['platform_hash'];

        // in addition to setting core values, we'll set any passed in values as well
        foreach($data as $name => $value) {
            if(strlen($value) > 0) {
                $this->dataValues[$name] = $value;
            }
        }
    }

    function setData($source, $data = array())
    {
        $userAgent = !empty($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $browser = UserAgentParser::getBrowser($userAgent);
        $os = UserAgentParser::getOperatingSystem($userAgent);

        $commonData = array(
                'x_host'		=> trim(shell_exec('hostname')),
                'u_ip_addr'             => !empty($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '',
                'u_viewer_id'           => MAX_cookieGetUniqueViewerId(),
                'u_new_viewer_id'       => !empty($GLOBALS['_MAX']['COOKIE']['newViewerId']) ? 1 : 0,
                'u_header_ua'           => $userAgent,
                'u_header_lang'         => !empty($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? $_SERVER['HTTP_ACCEPT_LANGUAGE'] : 'en',
                'u_header_prefetch'     => !empty($_SERVER['HTTP_X_MOZ']) && $_SERVER['HTTP_X_MOZ'] == 'prefetch' ? 1 : 0,
                'u_browser_name'        => $browser !== false ? $browser['id'] : '',
                'u_browser_vers'        => $browser !== false ? $browser['version'] : '',
                'u_os'                  => $os !== false ? $os['id'] : '',
                'u_ox_url'              => $this->getCurrentUrl(),
                );

        $cookieNamesToSet = LogLwes_getCookiesToSetInEvent();
        if(count($cookieNamesToSet) > 0) {
            $cookieString = '';
            foreach($cookieNamesToSet as $cookieName) {
                if(!empty($_COOKIE[$cookieName])) {
                    if(is_array($_COOKIE[$cookieName])) {
                        // NOTE: this is the custom cookie format for array values 
                        // that is written by OpenX in lib/max/Delivery/cookie.php
                        $cookieArrayData = array();
                        foreach($_COOKIE[$cookieName] as $customCookieKey => $customCookieValue) {
                            $cookieArrayData[] = $customCookieKey.'.'.$customCookieValue;
                        }
                        $cookieValue = implode('_', $cookieArrayData);
                    } else {
                        $cookieValue = $_COOKIE[$cookieName];
                    }
                    $cookieString .= $cookieName . "=" . urlencode($cookieValue) . "; "; 
                }
            }
            $commonData['u_header_ck'] = $cookieString;
        }

        // testing for IP blacklisting, user agent white listing or blacklisting. Setting flag to true means "problem" with this visitor
        if(isset($GLOBALS['_MAX']['EVENT_FILTER_FLAGS'])) {
            if(in_array('ignoreHosts_ip', $GLOBALS['_MAX']['EVENT_FILTER_FLAGS'])
                    || in_array('ignoreHosts_host', $GLOBALS['_MAX']['EVENT_FILTER_FLAGS']))
            {
                $commonData['x_ip_blst_g'] = true;
            }
            if(in_array('ignoreUserAgents', $GLOBALS['_MAX']['EVENT_FILTER_FLAGS'])) {
                $commonData['x_ua_blst'] = true;
            }
            if(in_array('enforceUserAgents', $GLOBALS['_MAX']['EVENT_FILTER_FLAGS'])) {
                $commonData['x_ua_no_wlst'] = true;
            }
        }

        // was the impression from an iframe automatically refreshed zone?
        if (!empty($_GET['refresh']) && is_numeric($_GET['refresh'])) {
            $commonData['x_autorefresh'] = true;
        }

        list($micro_seconds, $seconds) = explode(" ", microtime());
        $timeNowInMs = round(1000 *((float)$micro_seconds + (float)$seconds));
        $commonData['x_response_ms'] = $timeNowInMs - $GLOBALS['_MAX']['NOW_ms']; 

        $this->setCoreData ($source, array_merge ($commonData, $data));

    }
    
    protected function getEventId()
    {
        $id = sprintf('%08x', crc32(uniqid('', true)) >> 1);
        $id .= sprintf('%08x', crc32(uniqid('', true)));
        return $id;
    }
    
    protected function getCurrentUrl()
    {
    	$url = isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] ? 'https://' : 'http://'; 
    	$url .= $_SERVER['SERVER_NAME'] ;
		$url .= $_SERVER['REQUEST_URI'];
    	return $url;
    }
}
