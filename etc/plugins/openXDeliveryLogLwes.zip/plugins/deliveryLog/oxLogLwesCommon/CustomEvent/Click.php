<?php

class Lwes_Event_Click extends Lwes_Event_Common
{
    protected $eventType = 'HOX::Click';
    
	function getDataDefinition() {
		return array_merge(
			parent::getDataDefinition(), 
			array(
				'p_zone_id' 			=> array(self::DATA_TYPE_U_INT_32), //mediumint(9)
				'a_creative_localid'	=> array(self::DATA_TYPE_INT_32), //mediumint(9)
				'a_click_url'			=> array(self::DATA_TYPE_STRING, 2048), 
		));
		
	}
}

