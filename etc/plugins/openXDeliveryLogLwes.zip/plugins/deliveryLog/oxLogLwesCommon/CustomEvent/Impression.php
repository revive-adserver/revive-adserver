<?php

class Lwes_Event_Impression extends Lwes_Event_Common
{
    protected $eventType = 'HOX::Impression';
    
	function getDataDefinition() {
		return array_merge(
			parent::getDataDefinition(), 
			array(
				'p_zone_id' 				=> array(self::DATA_TYPE_U_INT_32), 
				'a_creative_localid'		=> array(self::DATA_TYPE_INT_32), 
				'a_campaign_localid'		=> array(self::DATA_TYPE_U_INT_32), 
			    'x_media_fallbk'			=> array(self::DATA_TYPE_BOOLEAN),
			    'x_autorefresh'			    => array(self::DATA_TYPE_BOOLEAN),
		));
		
	}
}

