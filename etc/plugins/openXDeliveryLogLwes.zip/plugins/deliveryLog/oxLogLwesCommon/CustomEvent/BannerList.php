<?php

class Lwes_Event_BannerList extends Lwes_Event_Common
{
    protected $eventType = 'HOX::BannerList';

    function getDataDefinition() {
        $customVarsDefinition = array();
        for ($i = 1; $i <= 256; $i++)
        {
            $customVarsDefinition['b'.$i] = array(self::DATA_TYPE_U_INT_32);
        }
        return array_merge(
                $customVarsDefinition,
                parent::getCoreDataDefinition(), 
                array(
                    'p_site_localid'	=> array(self::DATA_TYPE_U_INT_32),
                    'p_agency_localid'	=> array(self::DATA_TYPE_U_INT_32),
                    'p_zone_id'		=> array(self::DATA_TYPE_U_INT_32),
                    'a_advertiser_localid'=> array(self::DATA_TYPE_U_INT_32),
                    'a_creative_localid'	=> array(self::DATA_TYPE_INT_32),
                    'a_campaign_localid'	=> array(self::DATA_TYPE_U_INT_32), 

                    'x_max_index'         => array(self::DATA_TYPE_U_INT_16),
                    'x_ad_truncated'      => array(self::DATA_TYPE_U_INT_16),

                    ));
    }
    function setData($source, $data = array()) {
        parent::setCoreData($source, $data);
    }
}

