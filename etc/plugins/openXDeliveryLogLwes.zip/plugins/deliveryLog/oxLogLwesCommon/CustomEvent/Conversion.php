<?php

class Lwes_Event_Conversion extends Lwes_Event_Common
{
    protected $eventType = 'HOX::Conversion';
    
	function getDataDefinition() {
		return array_merge(
			parent::getDataDefinition(), 
			array(
		        'server_ip_addr'			=> array(self::DATA_TYPE_IP_ADDR),
		        'tracker_id'				=> array(self::DATA_TYPE_U_INT_32),
		        'tracker_action_timestamp'	=> array(self::DATA_TYPE_U_INT_32),
		        'tracker_creative_id'		=> array(self::DATA_TYPE_U_INT_32),
		        'tracker_zone_id'			=> array(self::DATA_TYPE_U_INT_32),
			
		        'tracker_window'			=> array(self::DATA_TYPE_U_INT_32),
				// see definitions in openx/constants.php MAX_CONNECTION_TYPE_*
		        'tracker_action_type'		=> array(self::DATA_TYPE_U_INT_32),
		        // see definitions in openx/constants.php MAX_CONNECTION_STATUS_*
		        'tracker_status'			=> array(self::DATA_TYPE_U_INT_32),
		));
		
	}
}

