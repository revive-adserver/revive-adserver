<?php

class Lwes_Event_Response extends Lwes_Event_Common
{
    protected $eventType = 'HOX::Response';
    
	function getDataDefinition() {
		$customVarsDefinition = array();
		for($i = 1; $i <= MAXIMUM_CUSTOM_VARIABLES_IN_EVENT; $i++) {
			$customVarsDefinition['p_opt'.$i.'_name'] = array(self::DATA_TYPE_STRING, MAXIMUM_LENGTH_CUSTOM_VARIABLE_NAME);
			$customVarsDefinition['p_opt'.$i.'_value'] = array(self::DATA_TYPE_STRING, MAXIMUM_LENGTH_CUSTOM_VARIABLE_VALUE);
		}
		return array_merge(
			parent::getDataDefinition(), 
			$customVarsDefinition,
			array(
				'a_creative_localid'	=> array(self::DATA_TYPE_INT_32),
				'a_campaign_localid'	=> array(self::DATA_TYPE_U_INT_32), 
				'a_camp_freq_cap'		=> array(self::DATA_TYPE_U_INT_16), 
				'a_advertiser_localid'	=> array(self::DATA_TYPE_U_INT_32),
				
				'p_zone_id'				=> array(self::DATA_TYPE_U_INT_32),
				'p_ad_width'			=> array(self::DATA_TYPE_U_INT_16),
				'p_ad_height'			=> array(self::DATA_TYPE_U_INT_16),
				'p_opt_truncated'		=> array(self::DATA_TYPE_U_INT_16),
				'p_site_localid'		=> array(self::DATA_TYPE_U_INT_32),
				'p_agency_localid'		=> array(self::DATA_TYPE_U_INT_32),

		        'u_geo_country'			=> array(self::DATA_TYPE_STRING, 2),
		        'u_geo_state'			=> array(self::DATA_TYPE_STRING, 2),
		        'u_geo_zip'				=> array(self::DATA_TYPE_STRING, 10),
		        'u_geo_area_code'		=> array(self::DATA_TYPE_U_INT_16),
		        'u_geo_dma'				=> array(self::DATA_TYPE_U_INT_16),
		        'u_geo_netspeed'		=> array(self::DATA_TYPE_STRING, 10),
			
		        'u_ox_refer_url'		=> array(self::DATA_TYPE_STRING, 2048),
			
			    'x_autorefresh'			=> array(self::DATA_TYPE_BOOLEAN),
		));
	}

    function setData($source, $data = array()) {
    	parent::setData($source, $data);
		if(!empty($_SERVER['GEOIP_COUNTRY_CODE'])) {
			// Field names already in use found in 
			// - https://svn.openx.org/private/resources/thorium/trunk/traffic.esf
			// - https://svn.openx.org/private/prenet/prototype/trunk/lib/Lwes/CommonEvent.php
			
			// GEOIP_* fields' names in found in:
			// - https://svn.openx.org/private/prenet/prototype/trunk/lib/Thorium/Enrichment/MaxMind.php
			$mappingFromLwesFieldsToGeoFields = array(
				'u_geo_country' 	=> 'GEOIP_COUNTRY_CODE',
				'u_geo_state' 		=> 'GEOIP_REGION',
				'u_geo_zip' 		=> 'GEOIP_POSTAL_CODE',
				'u_geo_dma' 		=> 'GEOIP_DMA_CODE',
		    	'u_geo_area_code' 	=> 'GEOIP_AREA_CODE',
				'u_geo_netspeed' 	=> 'GEOIP_NETSPEED',
                
				// not sent
//              'u_geo_organization' => 'GEOIP_ORGANIZATION',
//				'u_geo_postal_code' => '',
//				'u_geo_latitude' 	=> '',
//				'u_geo_longitude' 	=> '',
//				'u_geo_continent' 	=> '',
			);
			foreach($mappingFromLwesFieldsToGeoFields as $lwes => $original) {
				if(!empty($_SERVER[$original])) {
					$this->dataValues[$lwes] = $_SERVER[$original];
				}
			}
		}
	}
}

