<?php

require_once dirname(__FILE__) . "/LwesLib.php";

class Lwes_Emitter
{
    private $emitter;

    public function __construct($ip, $port)
    {
        Lwes_LwesLib::checkIfExtensionLoaded();
        $this->emitter = lwes_emitter_create($ip, null, $port, 0, 60);
    }

    public function __destruct()
    {
        if (!empty($this->emitter)) {
            lwes_emitter_destroy($this->emitter);
        }
    }

    public function emit($oEvent)
    {
        return lwes_emitter_emit($this->emitter, $oEvent->getEvent());
    }
}

?>