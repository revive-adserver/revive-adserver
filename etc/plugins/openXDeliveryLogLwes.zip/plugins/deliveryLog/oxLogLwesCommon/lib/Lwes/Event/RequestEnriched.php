<?php

class Lwes_Event_RequestEnriched extends Lwes_CommonEvent
{
    protected $eventType = 'Auction::Request::Enriched';

    public $aDataDefinition = array(
        'e_version'             => array(self::DATA_TYPE_INT_32),
        'e_id'                  => array(self::DATA_TYPE_STRING, 16),
        'e_auction_id'          => array(self::DATA_TYPE_STRING, 36),
        'e_req_time'            => array(self::DATA_TYPE_INT_32),
        'u_id'                  => array(self::DATA_TYPE_STRING, 36),
        'u_page_id'             => array(self::DATA_TYPE_INT_32),
        'p_channel'             => array(self::DATA_TYPE_STRING, 255),
        'u_ip_addr'             => array(self::DATA_TYPE_IP_ADDR),
        'u_ua_type'             => array(self::DATA_TYPE_STRING, 30),
        'u_ua_vers'             => array(self::DATA_TYPE_STRING, 5),
        'u_os_type'             => array(self::DATA_TYPE_STRING, 10),
        'u_os_vers'             => array(self::DATA_TYPE_STRING, 20),
        'u_languages'           => array(self::DATA_TYPE_STRING, 100),
        'u_geo_country'         => array(self::DATA_TYPE_STRING, 2),
        'u_geo_state'           => array(self::DATA_TYPE_STRING, 2),
        'u_geo_dma'             => array(self::DATA_TYPE_U_INT_16),
        'u_geo_area_code'       => array(self::DATA_TYPE_U_INT_16),
        'u_geo_netspeed'        => array(self::DATA_TYPE_STRING, 10),
        'u_page_url'            => array(self::DATA_TYPE_STRING, 2048),
        'p_id'                  => array(self::DATA_TYPE_STRING, 36),
        'p_floor_price'         => array(self::DATA_TYPE_STRING, 10),
        'p_site_category_1'     => array(self::DATA_TYPE_U_INT_16),
        'p_site_category_2'     => array(self::DATA_TYPE_U_INT_16),
        'p_ad_width'            => array(self::DATA_TYPE_U_INT_16),
        'p_ad_height'           => array(self::DATA_TYPE_U_INT_16),
        'p_block_categories'    => array(self::DATA_TYPE_STRING, 100),
        'p_block_attributes'    => array(self::DATA_TYPE_STRING, 100),
        'p_block_types'         => array(self::DATA_TYPE_STRING, 100),
        'a_broker_id'           => array(self::DATA_TYPE_U_INT_16),
    );

    function setData($source, $aData = array())
    {
        $this->prepareData($source->aParams);
        $this->setBlockedParameters($aData);

        if (!empty($source->aParams['context'])) {
            $aCategories = explode(',', $source->aParams['context']);
            if (!empty($aCategories[0])) {
                $this->aDataValues['p_site_category_1'] = $aCategories[0];
            }
            if (!empty($aCategories[1])) {
                $this->aDataValues['p_site_category_2'] = $aCategories[1];
            }
        }
    }
}

?>