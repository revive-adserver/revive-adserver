<?php

require_once BS_PATH . '/lib/Lwes/Event.php';

class Lwes_LwesLib extends Lwes_Event
{
    public static $emulate = false;
	
	public static function checkIfExtensionLoaded()
    {
        static $checked;
        if (!isset($checked)) {
            $checked = extension_loaded('lwes');
        }
        if (!$checked) {
        	if (self::$emulate) {
        		self::emulate();
        	}
        	else {
            	throw new Exception("Lwes extension not available");
        	}
        }
    }
    
    
    public static function emulate()
    {
		self::$emulate = true;
    	require_once (dirname(__FILE__) . '/LwesEmulator.php');
    }
}

?>
