<?php

class Lwes_Event_RequestReceived extends Lwes_CommonEvent
{
    protected $eventType = 'Auction::Request::Received';

    public $aDataDefinition = array(
        'e_version'     => array(self::DATA_TYPE_INT_32),
        'e_id'          => array(self::DATA_TYPE_STRING, 16),
        'e_auction_id'  => array(self::DATA_TYPE_STRING, 36),
        'e_req_time'    => array(self::DATA_TYPE_INT_32),
        'u_id'          => array(self::DATA_TYPE_STRING, 36),
        'u_page_id'     => array(self::DATA_TYPE_INT_32),
        'p_channel'     => array(self::DATA_TYPE_STRING, 255),
        'u_ip_addr'     => array(self::DATA_TYPE_IP_ADDR),
        'u_header_ua'   => array(self::DATA_TYPE_STRING, 64),
        'u_header_lang' => array(self::DATA_TYPE_STRING, 100),
        'u_page_url'    => array(self::DATA_TYPE_STRING, 2048),
        'p_id'          => array(self::DATA_TYPE_STRING, 36),
        'p_ad_width'    => array(self::DATA_TYPE_U_INT_16),
        'p_ad_height'   => array(self::DATA_TYPE_U_INT_16),
        'p_floor_price' => array(self::DATA_TYPE_STRING, 10),
        'a_broker_id'   => array(self::DATA_TYPE_U_INT_16),
    );

    function setData($source, $aData = array())
    {
        $this->prepareData($source->aParams);
    }
}

?>