<?php

require_once (dirname(__FILE__) . "/../AbstractRetargetingVar.php"); 

class Lwes_Event_RetargetingDeletevar extends Lwes_Event_AbstractRetargetingVar
{
    protected $eventType = 'Retargeting::Deletevar';
}

?>
