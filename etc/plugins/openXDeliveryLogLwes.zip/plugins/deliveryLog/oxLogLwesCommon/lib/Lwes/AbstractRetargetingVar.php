<?php

class Lwes_Event_AbstractRetargetingVar extends Lwes_CommonEvent
{
	protected $aParamsMapping = array();
    
    public $aDataDefinition = array(
        'e_version'    => array(self::DATA_TYPE_INT_32),
        'e_id'         => array(self::DATA_TYPE_STRING, 16),
        'rt_req_time'  => array(self::DATA_TYPE_INT_32),
        'u_id'         => array(self::DATA_TYPE_STRING, 36),
        'a_id'         => array(self::DATA_TYPE_U_INT_32, 4),
        'rt_var_name'  => array(self::DATA_TYPE_STRING, 64),
    );
	
    
    function setData(Indium_BaseVariableSetter $source, $aData = array())
    {
        if (!is_array($aData)) {
            $aData = array();
        }
        $this->prepareData($aData);
        $this->aDataValues['rt_req_time'] = $aData["time"];
		$this->aDataValues['u_id'] = $source->getOpenxId();
		$this->aDataValues['a_id'] = $source->getAccountId();
		$this->aDataValues['rt_var_name'] = $aData["name"];
    }
}

?>
