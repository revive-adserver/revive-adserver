<?php

class Lwes_Event_AuctionCompleted extends Lwes_CommonEvent
{
    protected $eventType = 'Auction::Complete';

    public $aDataDefinition = array(
        'e_version'                 => array(self::DATA_TYPE_INT_32),
        'e_id'                      => array(self::DATA_TYPE_STRING, 16),
        'e_auction_id'              => array(self::DATA_TYPE_STRING, 36),
        'e_req_time'                => array(self::DATA_TYPE_INT_32),
        'u_id'                      => array(self::DATA_TYPE_STRING, 36),
        'u_page_id'                 => array(self::DATA_TYPE_INT_32),
        'p_channel'                 => array(self::DATA_TYPE_STRING, 255),
        'u_ip_addr'                 => array(self::DATA_TYPE_IP_ADDR),
        'u_ua_type'                 => array(self::DATA_TYPE_STRING, 30),
        'u_ua_vers'                 => array(self::DATA_TYPE_STRING, 5),
        'u_os_type'                 => array(self::DATA_TYPE_STRING, 10),
        'u_os_vers'                 => array(self::DATA_TYPE_STRING, 20),
        'u_languages'               => array(self::DATA_TYPE_STRING, 100),
        'u_geo_country'             => array(self::DATA_TYPE_STRING, 2),
        'u_geo_state'               => array(self::DATA_TYPE_STRING, 2),
        'u_geo_dma'                 => array(self::DATA_TYPE_U_INT_16),
        'u_geo_area_code'           => array(self::DATA_TYPE_U_INT_16),
        'u_geo_netspeed'            => array(self::DATA_TYPE_STRING, 10),
        'u_page_url'                => array(self::DATA_TYPE_STRING, 2048),
        'p_id'                      => array(self::DATA_TYPE_STRING, 36),
        'p_floor_price'             => array(self::DATA_TYPE_STRING, 10),
        'p_site_category'           => array(self::DATA_TYPE_U_INT_16),
        'p_ad_width'                => array(self::DATA_TYPE_U_INT_16),
        'p_ad_height'               => array(self::DATA_TYPE_U_INT_16),
        'p_block_categories'        => array(self::DATA_TYPE_STRING, 100),
        'p_block_attributes'        => array(self::DATA_TYPE_STRING, 100),
        'p_block_types'             => array(self::DATA_TYPE_STRING, 100),
        'a_win_act_id'              => array(self::DATA_TYPE_U_INT_32, 4),
        'a_win_placement_id'        => array(self::DATA_TYPE_STRING, 16),
        'a_win_creative_id'         => array(self::DATA_TYPE_STRING, 16),
        'a_win_campaign_id'         => array(self::DATA_TYPE_STRING, 16),
        'a_win_bid'                 => array(self::DATA_TYPE_STRING, 10),
        'a_nowin1_id'               => array(self::DATA_TYPE_U_INT_32, 4),
        'a_nowin1_placement_id'     => array(self::DATA_TYPE_STRING, 16),
        'a_nowin1_bid'              => array(self::DATA_TYPE_STRING, 10),
        'a_price'                   => array(self::DATA_TYPE_STRING, 10),
        'a_win_creative_category'   => array(self::DATA_TYPE_U_INT_16),
        'a_win_creative_attributes' => array(self::DATA_TYPE_STRING, 30),
        'a_win_creative_type'       => array(self::DATA_TYPE_U_INT_16),
        'x_result_code'             => array(self::DATA_TYPE_STRING, 10),
        'p_revenue'                 => array(self::DATA_TYPE_STRING, 10),
        'x_revenue'                 => array(self::DATA_TYPE_STRING, 10),
        'x_depth'                   => array(self::DATA_TYPE_U_INT_16),
        'a_broker_id'               => array(self::DATA_TYPE_U_INT_16),
        'p_xenon_id'                => array(self::DATA_TYPE_STRING, 36),
        'a_win_xenon_id'            => array(self::DATA_TYPE_STRING, 36),
        'x_rtb_eligible'            => array(self::DATA_TYPE_U_INT_16),
        'x_mm_test'            => array(self::DATA_TYPE_BOOLEAN),
    );

    function setData($source, $aData = array())
    {
        if (!is_array($aData)) {
            $aData = array();
        }
        $this->prepareData($source->aParams + $aData);
        $bidStatus = 'NOBID';

        if (!empty($aData)) {
            $bidStatus = 'WON';
            $this->setBlockedParameters($source->website);

            $aGlobals = Zend_Registry::get('aConf[globals]');

            $accountId = $this->aDataValues['a_win_act_id'] = $aData['aAccount']['accountId'];
            $this->aDataValues['a_win_xenon_id'] = $source->aAccounts[$accountId]['xenonAccountId'];
            $this->aDataValues['a_win_placement_id'] = $aData['aBid']['bid_id'];
            $this->aDataValues['a_win_creative_id'] = $aData['aBid']['creative_id'];
            $this->aDataValues['a_win_campaign_id'] = $aData['aBid']['campaign_id'];
            $this->aDataValues['a_win_bid'] = $aData['aBid']['bid'];
            $this->aDataValues['x_mm_test'] = isset($aData['aBid']['mm_test']) ? $aData['aBid']['mm_test'] : false;

            if (isset($aData['runnerUpBid'])) {
                $this->aDataValues['a_nowin1_id'] = $aData['runnerUpBid']['creative_id'];
                $this->aDataValues['a_nowin1_placement_id'] = $aData['runnerUpBid']['bid_id'];
                $this->aDataValues['a_nowin1_bid'] = $aData['runnerUpBid']['bid'];
            }

            $this->aDataValues['x_depth'] = $this->getParamByName($aData, 'cBids');
        }
        $this->aDataValues['x_rtb_eligible'] = $source->aParams['x_rtb_count'];
        $this->aDataValues['x_result_code'] = $bidStatus;
        if(isset($source->website)) {
            $this->aDataValues['p_xenon_id'] = $source->website['xenonAccountId'];
        }
    }
}

?>
