<?php

class Lwes_Event_ImpressionDisplayed extends Lwes_CommonEvent
{
    protected $eventType = 'Impression::Displayed';

    public $aDataDefinition = array(
        'e_version'             => array(self::DATA_TYPE_INT_32),
        'e_id'                  => array(self::DATA_TYPE_STRING, 16),
        'e_auction_id'          => array(self::DATA_TYPE_STRING, 36),
        'e_req_time'            => array(self::DATA_TYPE_INT_32),
        'u_id'                  => array(self::DATA_TYPE_STRING, 16),
        'u_page_id'             => array(self::DATA_TYPE_INT_32),
        'u_ip_addr'             => array(self::DATA_TYPE_IP_ADDR),
        'u_header_ua'           => array(self::DATA_TYPE_STRING, 64),
        'u_header_lang'         => array(self::DATA_TYPE_STRING, 100),
        'u_page_url'            => array(self::DATA_TYPE_STRING, 2048),
        'a_win_act_id'          => array(self::DATA_TYPE_U_INT_32, 4),
        'a_win_placement_id'    => array(self::DATA_TYPE_STRING, 16),
        'a_win_creative_id'     => array(self::DATA_TYPE_STRING, 16),
        'a_price'               => array(self::DATA_TYPE_STRING, 10),
        'p_revenue'             => array(self::DATA_TYPE_STRING, 10),
        'x_revenue'             => array(self::DATA_TYPE_STRING, 10),
        'a_broker_id'           => array(self::DATA_TYPE_U_INT_16),
    );

    /**
     * Mapping used to partly overwrite original mapping
     */
    protected $aEventParamsMapping = array(
        'a_win_act_id' => 'accountId', // winning advertiser ID
        'e_auction_id' => 'auctionId', // Generated UUID for this auction
        'e_req_time' => 'auctionTimestamp', // Unix time marketplace received the request
        'a_win_placement_id' => 'bidId', // The ID of the winning placement
        'a_win_creative_id' => 'creativeId', // The ID of the winning creative
    );

    function __construct()
    {
        parent::__construct();
        foreach ($this->aEventParamsMapping as $k => $v) {
            $this->aParamsMapping[$k] = $v;
        }
    }

    function setData($source, $aData = array())
    {
        if (!is_array($aData)) {
            $aData = array();
        }
        $this->prepareData($aData + $source->aParams);
    }
}

?>