<?php

require_once dirname(__FILE__) . "/LwesLib.php";

class Lwes_Event
{
    private $event;

    const ERROR_WRONG_ATTRIBUTE = -1;
    const ERROR_WRONG_TYPE = -2;
    const ERROR_UNKNOWN = -3;

    public $aErrorCodes = array(
        self::ERROR_WRONG_ATTRIBUTE => 'Wrong attribute',
        self::ERROR_WRONG_TYPE => 'Wrong type',
        self::ERROR_UNKNOWN => 'Server unknown error',
    );

    public function __construct($eventName = 'EventName', $db = null)
    {
        Lwes_LwesLib::checkIfExtensionLoaded();
        $this->event = lwes_event_create($db, $eventName);
    }

    public function __destruct()
    {
        if (!empty($this->event)) {
            lwes_event_destroy($this->event);
        }
    }

    function getErrorMessage($errorCode)
    {
        if(isset($this->aErrorCodes[$errorCode])) {
            return $this->aErrorCodes[$errorCode];
        }
        return $this->aErrorCodes[self::ERROR_UNKNOWN];
    }

    public function &getEvent()
    {
        return $this->event;
    }

    public function setU_INT_16($name, $value)
    {
        return lwes_event_set_U_INT_16($this->event, $name, $value);
    }

    public function setINT_16($name, $value)
    {
        return lwes_event_set_INT_16($this->event, $name, $value);
    }

    public function setU_INT_32($name, $value)
    {
        return lwes_event_set_U_INT_32($this->event, $name, $value);
    }

    public function setINT_32($name, $value)
    {
        return lwes_event_set_INT_32($this->event, $name, $value);
    }

    public function setSTRING($name, $value)
    {
        return lwes_event_set_STRING($this->event, $name, $value);
    }

    public function setIP_ADDR($name, $value)
    {
        return lwes_event_set_IP_ADDR_w_string($this->event, $name, $value);
    }

    public function setBOOLEAN($name, $value)
    {
        return lwes_event_set_BOOLEAN($this->event, $name, $value);
    }
}

?>
