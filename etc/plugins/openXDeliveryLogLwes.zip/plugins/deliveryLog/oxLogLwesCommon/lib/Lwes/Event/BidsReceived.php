<?php

class Lwes_Event_BidsReceived extends Lwes_CommonEvent
{
    const LOG_BIDS = 10;

    protected $eventType = 'Auction::Bids::Received';

    public $aDataDefinition = array(
        'e_version'          => array(self::DATA_TYPE_INT_32),
        'e_id'               => array(self::DATA_TYPE_STRING, 16),
        'e_auction_id'       => array(self::DATA_TYPE_STRING, 36),
        'e_req_time'         => array(self::DATA_TYPE_INT_32),
        'participants_count' => array(self::DATA_TYPE_U_INT_16),
        'bid_depth'          => array(self::DATA_TYPE_U_INT_16),
        'floor_price'        => array(self::DATA_TYPE_STRING, 10),
        'a_broker_id'        => array(self::DATA_TYPE_U_INT_16),
    );

    function __construct()
    {
        parent::__construct();
        for ($i = 1; $i <= self::LOG_BIDS; $i++) {
            $this->aDataDefinition += array(
                "b{$i}_act_id"          => array(self::DATA_TYPE_U_INT_32, 4),
                "b{$i}_placement_id"    => array(self::DATA_TYPE_STRING, 16),
                "b{$i}_price"           => array(self::DATA_TYPE_STRING, 10),
            );
        }
        $this->aParamsMapping['bid_depth'] = 'cBids';
    }

    function setData(Thorium_Broker $source, $aData = array())
    {
        if (!is_array($aData)) {
            $aData = array();
        }
        $this->prepareData($source->aParams + $aData);
        $this->aDataValues['participants_count'] = count($source->aAccounts);
        $aGlobals = Zend_Registry::get('aConf[globals]');
        if (isset($aData['aBids'])) {
            $i = 1;
            foreach ($aData['aBids'] as $aBid) {
                $accountId = $aBid['account_id'];
                $brokerId  = $aGlobals['clusterId'];
                $this->setBidData($aBid, $accountId, $brokerId, $i++);

                if ($i == self::LOG_BIDS) {
                    break;
                }
            }
        }
    }

    function setBidData($aBid, $accountId, $brokerId, $counter)
    {
        $this->aDataValues["b{$counter}_act_id"] = $accountId;
        $this->aDataValues["b{$counter}_broker_id"] = $brokerId;
        $this->aDataValues["b{$counter}_placement_id"] = $this->getParamByName($aBid, 'bid_id');
        $this->aDataValues["b{$counter}_price"] = $this->getParamByName($aBid, 'bid');
    }

}

?>
