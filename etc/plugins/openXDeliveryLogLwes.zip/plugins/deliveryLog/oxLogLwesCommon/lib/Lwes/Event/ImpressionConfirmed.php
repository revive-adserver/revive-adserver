<?php

class Lwes_Event_ImpressionConfirmed extends Lwes_CommonEvent
{
    protected $eventType = 'Impression::Confirmed';

    public $aDataDefinition = array(
        'e_version'             => array(self::DATA_TYPE_INT_32),
        'e_id'                  => array(self::DATA_TYPE_STRING, 16),
        'e_auction_id'          => array(self::DATA_TYPE_STRING, 36),
        'e_req_time'            => array(self::DATA_TYPE_INT_32),
        'u_id'                  => array(self::DATA_TYPE_STRING, 16),
        'u_page_id'             => array(self::DATA_TYPE_INT_32),
        'u_ip_addr'             => array(self::DATA_TYPE_IP_ADDR),
        'u_header_ua'           => array(self::DATA_TYPE_STRING, 64),
        'u_header_lang'         => array(self::DATA_TYPE_STRING, 100),
        'u_page_url'            => array(self::DATA_TYPE_STRING, 2048),
        'a_win_act_id'          => array(self::DATA_TYPE_U_INT_32, 4),
        'a_win_placement_id'    => array(self::DATA_TYPE_STRING, 16),
        'a_win_creative_id'     => array(self::DATA_TYPE_STRING, 16),
        'a_price'               => array(self::DATA_TYPE_STRING, 10),
        'p_revenue'             => array(self::DATA_TYPE_STRING, 10),
        'x_revenue'             => array(self::DATA_TYPE_STRING, 10),
        'a_broker_id'           => array(self::DATA_TYPE_U_INT_16),
        'x_rtb_count'           => array(self::DATA_TYPE_U_INT_16),
        'x_rtb_rcd'             => array(self::DATA_TYPE_U_INT_16),
        
        'p_floor_price'         => array(self::DATA_TYPE_STRING, 10),
        
        'a_rtb1_act_id'         => array(self::DATA_TYPE_U_INT_32),
        'a_rtb2_act_id'         => array(self::DATA_TYPE_U_INT_32),
        'a_rtb3_act_id'         => array(self::DATA_TYPE_U_INT_32),
        'a_rtb1_campaign_id'    => array(self::DATA_TYPE_STRING, 16),
        'a_rtb2_campaign_id'    => array(self::DATA_TYPE_STRING, 16),
        'a_rtb3_campaign_id'    => array(self::DATA_TYPE_STRING, 16),
        'a_rtb1_bid'            => array(self::DATA_TYPE_STRING, 10),
        'a_rtb2_bid'            => array(self::DATA_TYPE_STRING, 10),
        'a_rtb3_bid'            => array(self::DATA_TYPE_STRING, 10),
    
        'a_win_xenon_id'        => array(self::DATA_TYPE_STRING, 36),
        'a_win_campaign_id'     => array(self::DATA_TYPE_STRING, 16),
        'a_nowin1_id'           => array(self::DATA_TYPE_U_INT_32),
        'a_nowin1_placement_id'     => array(self::DATA_TYPE_STRING, 16),
        'a_nowin1_bid'              => array(self::DATA_TYPE_STRING, 10),
        'x_result_code'             => array(self::DATA_TYPE_STRING, 10),
        'a_win_bid'                 => array(self::DATA_TYPE_STRING, 10),
        'a_win_creative_categories'   => array(self::DATA_TYPE_STRING, 100),
        'a_win_creative_attributes' => array(self::DATA_TYPE_STRING, 100),
        'a_win_creative_types'       => array(self::DATA_TYPE_STRING, 100),
        'a_win_rtb_signature_ok'              => array(self::DATA_TYPE_BOOLEAN)
    );
    
    
    /**
     * Mapping used to partly overwrite original mapping
     */
    protected $aEventParamsMapping = array(
        'a_win_act_id' => 'accountId', // winning advertiser ID
        'e_auction_id' => 'auctionId', // Generated UUID for this auction
        'e_req_time' => 'auctionTimestamp', // Unix time marketplace received the request
        'a_win_placement_id' => 'bidId', // The ID of the winning placement
        'a_win_creative_id' => 'creativeId', // The ID of the winning creative
        'a_win_creative_categories' => 'creativeCategory',
        'a_win_creative_attributes' => 'creativeAttributes',
        'a_win_creative_types' => 'creativeType',
        'a_win_bid' => 'winningBid',
    );

    function __construct()
    {
        parent::__construct();
        foreach ($this->aEventParamsMapping as $k => $v) {
            $this->aParamsMapping[$k] = $v;
        }
    }

    function setData($source, $aData = array())
    {
        if (!is_array($aData)) {
            $aData = array();
        }
        $this->prepareData($aData + $source->aParams);
        
        if (isset($aData['rtbBids'])) {
        	$this->setRtbData($source, $aData);
        }
    }
    
    
    public function setRtbData($source, $data)
    {        
        $i = 0;
    	foreach ($data['rtbBids'] as $bid) {
    		if (++$i == 4) {
    			return;
    		}
            $this->aDataValues["a_rtb{$i}_act_id"] = $bid['accountId'];
            $this->aDataValues["a_rtb{$i}_campaign_id"] = $bid['campaignId'];
            $this->aDataValues["a_rtb{$i}_bid"] = $bid['bid'];
        }
        
        $this->aDataValues['x_rtb_rcd'] = count($data['rtbBids']);
        $this->aDataValues['x_rtb_count'] = $data['rtbCount'];
        $this->aDataValues['p_floor_price'] = $data['floorPrice'] - $data['floorCommission'];
        if (isset($data['second'])) {
        	$this->aDataValues['a_nowin1_id'] = $data['second']['accountId'];
        	$this->aDataValues['a_nowin1_placement_id'] = $data['second']['bidId'];
        	$this->aDataValues['a_nowin1_bid'] = $data['second']['bid'];
        }
        
        if ($data['accountId']) {
            $this->aDataValues['a_win_xenon_id'] = $source->aAccounts[$data['accountId']]['xenonAccountId'];
            $this->aDataValues['a_win_campaign_id'] = $data['campaignId'];
            $this->aDataValues['x_result_code'] = ($data['winner']['rtb']) ? 'RT_WON' : 'WON';
            if ($data['winner']['rtb']) {
            	$this->aDataValues['a_win_rtb_signature_ok'] = $data['winner']['signature_ok'];
            }
        }
        else {
        	$this->aDataValues['x_result_code'] = 'NOBID';
        }
    }
}

?>
