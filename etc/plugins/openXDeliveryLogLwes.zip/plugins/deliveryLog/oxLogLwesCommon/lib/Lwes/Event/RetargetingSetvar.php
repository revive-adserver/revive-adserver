<?php

require_once (dirname(__FILE__) . "/../AbstractRetargetingVar.php"); 

class Lwes_Event_RetargetingSetvar extends Lwes_Event_AbstractRetargetingVar
{
    protected $eventType = 'Retargeting::Setvar';

    function __construct()
    {
    	$this->aDataDefinition = $this->aDataDefinition + 
    		array('rt_var_value' => array(self::DATA_TYPE_STRING, 255));
    }

    function setData($source, $aData = array())
    {
        parent::setData($source, $aData);
        $this->aDataValues['rt_var_value'] = $aData["value"];
    }
}

?>
