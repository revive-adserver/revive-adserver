<?php

class LwesEmitterEmulator
{
	public $address;
	private $iface;
	private $port;
	private $emit_heartbeat;
	private $freq;
	
	function __construct($address, $iface, $port, $emit_heartbeat, $freq)
	{
		$this->address = $address;
		$this->iface = $iface;
		$this->port = $port; 
		$this->emit_heartbeat = $emit_heartbeat;
		$this->freq = $freq;
	}
}


class LwesEventEmulator
{
	public $eventType;
	public $attributes = array();
	public $types = array();
	
	function __construct($eventType)
	{
		$this->eventType = $eventType;
	}
	
	public function setAttribute($name, $value, $type)
	{
		 $this->attributes[$name] = $value;
		 $this->types[$name] = $type;
	}
}


class LwesEventCollector
{
	public $events = array();
	
	function __construct()
	{
		//echo "SETTING CALLBACK<BR>\n";
		lwes_set_emit_callback(array($this, "emit"));
	}
	
	
	function emit(LwesEmitterEmulator $emitter, LwesEventEmulator $event)
	{
		//echo "COLLECTING EVENT<BR>\n";
		$this->events[] = $event;
	}
	
	/**
	 * @return LwesEventEmulator
	 */
	function removeFirst()
	{
		return array_shift($this->events);
	}
}

function lwes_emitter_create($address, $iface, $port, $emit_heartbeat, $freq)
{
	return new LwesEmitterEmulator($address, $iface, $port, $emit_heartbeat, $freq);
}


function lwes_event_type_db_create($filename)
{
	return null;
}


function lwes_event_create($type_db, $eventName)
{
	return new LwesEventEmulator($eventName);
}

function create_lwes_event_set($type)
{
	$code = "function lwes_event_set_" . $type
		. "(\$event, \$attribute, \$value)\n"
		. "{\n\$event->setAttribute(\$attribute, \$value, \"" . $type . "\");\n}\n";
	eval($code);
}


create_lwes_event_set("U_INT_32");
create_lwes_event_set("INT_32");
create_lwes_event_set("U_INT_16");
create_lwes_event_set("INT_16");
create_lwes_event_set("STRING");
create_lwes_event_set("IP_ADDR_w_string");
create_lwes_event_set("BOOLEAN");

function lwes_emitter_destroy($emitter)
{
}

function lwes_event_destroy($event)
{
}

function lwes_log_event($msg)
{
    // when using the lwes library in other projects, Common might not be defined
    // (for example, in the Lwes plugin for the Ad Server)
    if(method_exists('Common', 'log')) {
        Common::log('lwes.log', array($msg));
    } else { 
        echo $msg;
    }
}

function event_dumper(LwesEmitterEmulator $emitter, LwesEventEmulator $event)
{
	lwes_log_event("<BR>\nEmmiting event " . $event->eventType . " to " . $emitter->address . "<BR>\n");
	foreach ($event->attributes as $name=>$value) {
		lwes_log_event($name . " = " . $value . "(" . $event->types[$name] . ")<BR>\n");
	}
}

function lwes_set_emit_callback($callback)
{
	global $emitCallback;
	$emitCallback = $callback;
}

lwes_set_emit_callback("event_dumper");

function lwes_emitter_emit(LwesEmitterEmulator $emitter, LwesEventEmulator $event)
{
	global $emitCallback;
//	echo "emiiting to callback = ";
//	var_dump($emitCallback);
//	echo "<BR>\n";
	call_user_func_array($emitCallback, array($emitter, $event));
}

?>
