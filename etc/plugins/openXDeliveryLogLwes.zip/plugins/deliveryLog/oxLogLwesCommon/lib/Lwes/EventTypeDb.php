<?php

require_once BS_PATH . '/lib/Lwes/Event.php';

class Lwes_EventTypeDb extends Lwes_Event
{
    private $event;
    const ESF_FILE_PATH = '../../resources/traffic/traffic.esf';
	private static $db = null;
	
    public function __construct($eventName = 'EventName', $esfFilePath = null)
    {
        Lwes_LwesLib::checkIfExtensionLoaded();
     	$esfFilePath = is_null($esfFilePath) ? self::ESF_FILE_PATH : $esfFilePath;
     	
     	// this test should be un-commented, but I don't want to break Thorium 
     	// if you see this code, please uncomment and make sure the test pass in Thorium
     	// it seems the path must be absolute (eg. prepend BS_PATH to it?)
//        if(!file_exists($esfFilePath)) {
//			throw new Exception(".esf file not found: $esfFilePath");
//		}
     	if (is_null(self::$db)) {
            self::$db = lwes_event_type_db_create($esfFilePath);
        }
        parent::__construct($eventName, self::$db);
    }
}

?>
