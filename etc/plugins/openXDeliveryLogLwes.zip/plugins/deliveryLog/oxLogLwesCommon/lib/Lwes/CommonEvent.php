<?php

require_once BS_PATH . '/lib/Lwes/EventTypeDb.php';

/**
 * See: https://developer.openx.org/wiki/display/PT/Event+Types
 *
 */
class Lwes_CommonEvent
{
    /**
     * Supported LWES data types
     */
    const DATA_TYPE_U_INT_16 = 'U_INT_16';
    const DATA_TYPE_INT_16   = 'INT_16';
    const DATA_TYPE_U_INT_32 = 'U_INT_32';
    const DATA_TYPE_INT_32   = 'INT_32';
    const DATA_TYPE_STRING   = 'STRING';
    const DATA_TYPE_IP_ADDR  = 'IP_ADDR';
    const DATA_TYPE_BOOLEAN  = 'BOOLEAN';

    /**
     * Event version
     */
    const EVENT_VERSION = 37781;

    public $aData = array();
    protected $eventType;

    /**
     * Data passed from the source class from which the event was dispatched
     */
    protected $_source;
    protected $_data;

    /**
     * List of default params passed to dispatcher and its
     * mapping to coresponding event types
     *
     * Format:
     * array (mappingTo => mappingFrom...)
     * mappingTo - the target mapping to which the mapping is done
     * mappingFrom - the source mapping from which the mapping is done
     *
     * @var array
     */
    protected $aParamsMapping = array(
        'e_auction_id'      => 'auction_id', // Generated UUID for this auction
        'e_req_time'        => 'auction_timestamp', // Unixtime marketplace received the request
        'p_floor_price'     => 'f', // inventory floor price
        'floor_price'       => 'f', // inventory floor price ?? - should it be callse p_floor_price?
        'u_ip_addr'         => 'ip_address', // user IP address
        'u_header_lang'     => 'raw_language', // unparsed Accept-Language header
        'u_page_id'         => 'page_id', // user page ID
        'p_channel'         => 'cid', // channel ID
        'p_id'              => 'pid', // website ID
        'u_page_url'        => 'url', // The URL of the page being viewed by the user
        'u_header_ua'       => 'user_agent', // unparsed User-Agent header
        'u_ua_type'         => 'browser_type', // user's browser type
        'u_ua_vers'         => 'browser_version', // user's browser version
        'u_os_type'         => 'os_type', // user's operating system type
        'u_os_vers'         => 'os_version', // user's operating system version
        'u_languages'       => 'language', // user's accepted languages
        'u_geo_country'     => 'country', // user's country
        'u_geo_state'       => 'region', // user's state/province code
        'u_geo_dma'         => 'dma_code', // user's DMA code
        'u_geo_area_code'   => 'area_code', // user's area code
        'u_geo_netspeed'    => 'netspeed', // user's connection speed
        'u_geo_netspeed'    => 'netspeed', // user's connection speed
    );

    /**
     * Data types - may be overwritten in child classes
     *
     * Format:
     *  field name => array(data type, size)
     *
     * @var array
     */
    public $aDataDefinition = array();

    /**
     * Data which will be used to build an Event object (using
     * the data formatiing defined in $aDataDefinition)
     *
     * @var unknown_type
     */
    public $aDataValues = array();

    public function __construct()
    {
    }

    public static function &factory($eventType)
    {
        $className = 'Lwes_Event_'.$eventType;
        if (!class_exists($className)) {
            if (!@include('Event/'.$eventType.'.php')) {
                throw new Exception("Event '{$eventType}' not implemented");
            }
        }
        if (!class_exists($className)) {
            throw new Exception("EventType class name '$className' not implemented");
        }
        $oEvent = new $className();
        return $oEvent;
    }

    function setData($source, $aData = array())
    {
        throw new Exception('setData method not implemented');
    }

    function getEventObject($eventData = null)
    {
        if ($eventData !== null) {
            $this->setData($eventData);
        }
        $oEvent = $this->getEvent();
        foreach ($this->aDataDefinition as $name => $aType) {
            if (isset($this->aDataValues[$name])) {
                $this->addToEvent($oEvent, $name, $this->aDataValues[$name], $aType[0], isset($aType[1]) ? $aType[1] : null);
            }
        }
        return $oEvent;
    }

    function getEvent()
    {
        return new Lwes_EventTypeDb($this->eventType);
    }

    function addToEvent($oEvent, $key, $dataValue, $dataType, $dataLength = null)
    {
        // Truncate strings
        if ($dataType == self::DATA_TYPE_STRING) {
            if ($dataLength < 1) {
                throw new Exception('Invalid data length for key: '.$key);
            }
            $dataValue = substr($dataValue, 0, $dataLength);
        }

        $addMethod = 'set'.$dataType;
        if (method_exists($oEvent, $addMethod)) {
            $ret = $oEvent->$addMethod($key, $dataValue, $dataLength);
            if ($ret < 0) {
                throw new Exception('Error setting attribute, name: '.$key.', error type: '
                    . $oEvent->getErrorMessage($ret));
            }
        } else {
            throw new Exception('Set method not defined for data type: '.$dataType);
        }
    }

    /**
     * Sets the default data which is common (or is shared)
     * between different events
     *
     * @param array $aParams
     * @param arrat $aParamsMapping - see $this->aParamsMapping for a definition
     */
    function prepareData($aParams, $aParamsMapping = null)
    {
        if (is_null($aParamsMapping)) {
            $aParamsMapping = $this->aParamsMapping;
        }
        foreach ($this->aDataDefinition as $name => $aType) {
            if (isset($aParamsMapping[$name])) {
                $this->aDataValues[$name] =
                    $this->setFromParams($name, $aParams, $aParamsMapping);
            } else {
                $methodName = 'get_' . $name;
                if(method_exists($this, $methodName)) {
                    $this->aDataValues[$name] = $this->$methodName($aParams);
                }
            }
        }
    }

    function setFromParams($name, $aParams, $aParamsMapping)
    {
        return $this->getParamByName($aParams, $aParamsMapping[$name]);
    }

    function getParamByName($aParams, $name, $default = '')
    {
        return isset($aParams[$name]) ? $aParams[$name] : $default;
    }

    /**
     * Common Data functions - Event Version
     */
    function get_e_version()
    {
        return self::EVENT_VERSION;
    }

    /**
     * Common Data functions - broker Id
     */
    function get_a_broker_id()
    {
      /* hardcoding this as it is going away anyway */
        return 1;
    }

    /**
     * Common Data functions - Event ID
     */
    function get_e_id()
    {
        $id = sprintf('%08x', crc32(uniqid('', true)) >> 1);
        $id .= sprintf('%08x', crc32(uniqid('', true)));
        return $id;
    }

    /**
     * Indium UUID for the user
     *
     * @param array $aParams
     * @return integer or empty string if not set
     */
    function get_u_id($aParams)
    {
        return !empty($aParams['viewer_id']) ? ($aParams['viewer_id']) : '';
    }

    /**
     * Width of the ad space
     *
     * @param array $aParams
     * @return integer or empty string if not set
     */
    function get_p_ad_width($aParams)
    {
        $pos = strpos($aParams['s'], 'x');
        return $pos ? substr($aParams['s'], 0, $pos) : '';
    }

    /**
     * height of the ad space
     *
     * @param array $aParams
     * @return integer or empty string if not set
     */
    function get_p_ad_height($aParams)
    {
        $pos = strpos($aParams['s'], 'x');
        return $pos ? substr($aParams['s'], $pos+1, strlen($aParams['s'])) : '';
    }

    /**
     * The advertiser price for this auction - actual cost after bubble popping
     *
     * @param array $aParams
     * @return integer or empty string if not set
     */
    function get_a_price($aParams)
    {
        if (!isset($aParams['winningPrice'])) {
            return '';
        }
        return $aParams['winningPrice'];
    }

    /**
     * The payment due to OpenX
     *
     * @param array $aParams
     * @return integer or empty string if not set
     */
    function get_x_revenue($aParams)
    {
        if (!isset($aParams['winningCommission'])) {
            return '';
        }
        return $aParams['winningCommission'];
    }

    /**
     * The payment due to website
     *
     * @param array $aParams
     * @return integer or empty string if not set
     */
    function get_p_revenue($aParams)
    {
        if (!isset($aParams['winningCommission']) || !isset($aParams['winningPrice'])) {
            return '';
        }
        return $aParams['winningPrice'] - $aParams['winningCommission'];
    }

    /**
     * Sets block_* categories, attributes and types
     *
     * @param Thorium $source
     * @param array $aParams
     */
    function setBlockedParameters($website)
    {
        if ($website) {
            $this->aDataValues['p_block_categories'] = join(',', $website['catEx']);
            $this->aDataValues['p_block_attributes'] = join(',', $website['attEx']);
            $this->aDataValues['p_block_types']      = join(',', $website['typEx']);
        }
    }
}

?>
