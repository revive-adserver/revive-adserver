<?php
require_once LIB_PATH . '/Extension/deliveryLog/DeliveryLog.php';

class Plugins_DeliveryLog_OxLogLwes_LogLwes extends Plugins_DeliveryLog
{
    function getDependencies()
    {
        return array($this->getComponentIdentifier() => array());
    }
    
    // onEnable, picks up platform_hash from the DB and saves it in the config file
    function onEnable()
    {
        OA_Dal_ApplicationVariables::cleanCache();
    	$platformHash = OA_Dal_ApplicationVariables::get('platform_hash', false);
		$oSettings  = new OA_Admin_Settings();
		$oSettings->settingChange('oxLogLwes','platform_hash',$platformHash);
		$oSettings->writeConfigChange();
    	return parent::onEnable();
    }
    
    // TODO these methods should NOT be abstract
    function getBucketName() { return ''; }
    function getBucketTableColumns() { return array(); }
    function getStatisticsName() { return ''; }
	function getStatisticsMigration() {	return array(); }
	// TODO openx distributed maintenance shouldn't break when these are not defined
	// see OXPP-33
    function processBucket() { return true; }
    function pruneBucket() { return true; }
    

}
