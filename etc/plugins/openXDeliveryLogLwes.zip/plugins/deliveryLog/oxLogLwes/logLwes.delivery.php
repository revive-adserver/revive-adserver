<?php
if(!function_exists('Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_init')) {
    if (!defined ('BS_PATH')) {
      define('BS_PATH', MAX_PATH . "/plugins/deliveryLog/oxLogLwesCommon/");
    }
    define('VARIABLE_REQUEST_ID', 'r_id');
    define('VARIABLE_REQUEST_TIMESTAMP', 'r_ts');
    define('MAXIMUM_CUSTOM_VARIABLES_IN_EVENT', 10);
    define('MAXIMUM_LENGTH_CUSTOM_VARIABLE_VALUE', 32);
    define('MAXIMUM_LENGTH_CUSTOM_VARIABLE_NAME', 32);
    define('MAXIMUM_BANNERLIST_BANNERS', 256);
    define('PATH_ESF_DEFINITION_FILE', BS_PATH . '/resources/hox.esf');

    require_once BS_PATH . 'Lwes.php';
    require_once BS_PATH . 'CustomEvent/Common.php';
    
    function Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_init()
    {
        if($GLOBALS['_MAX']['CONF']['oxLogLwes']['debug']) {
            Lwes_LwesLib::$emulate = true;
        }
        if (!isset ($GLOBALS['_MAX']['OxLogLwes']['lwes'])) {
          $GLOBALS['_MAX']['OxLogLwes']['lwes'] = new Plugin_oxDeliveryLogLwes_Lwes($GLOBALS['conf']['oxLogLwes']);
          $GLOBALS['_MAX']['OxLogLwes']['lwes']->setEsfFilePath(PATH_ESF_DEFINITION_FILE);
        }
    }
    
    /**
     * Publishers can define custom parameters directly setting them in their delivery URLs.
     * This function will read parameters from the current GET URL, and return the ones that are custom.
     * 
     * Known parameters are the ones that:
     * - are used by OpenX core found in various places in the code...
     * - are defined in the config file in the [var] section
     * - are persisted by plugins using the addUrlParams hook
     * 
     * @return array of key->value
     */
    function Plugin_deliveryLog_OxLogLwes_getCustomVarsFromUrl()
    {
        $knownOpenXVarNames = array_values($GLOBALS['_MAX']['CONF']['var']);
        
        $pluginVarNames = array();
        $pluginVarNamesByComponent = OX_Delivery_Common_hook('addUrlParams', array());
        foreach($pluginVarNamesByComponent as $component => $varNames) {
            $pluginVarNames = array_merge($pluginVarNames, $varNames);
        }
        $pluginVarNames = array_keys($pluginVarNames);
        
        $otherVarNames = array(    
                                // found in lib/max/Delivery/common.php:L370
                                'context', 
                                'target', 
                                'withText', 
                                'withtext', 
                                'ct0', 
                                'what', 
                                'loc', 
                                'referer', 
                                'zoneid', 
                                'campaignid', 
                                'bannerid', 
                                'clientid', 
                                'charset',
                                
                                // found in ac.php
                                'timeout',
        
                                // found in afr.php
                                'refresh', 
                                'resize', 
                                'rewrite', 
                                'n',
        
                                // found in ai.php
                                'filename', 
                                'contenttype',
        
                                // found in ajs.php
                                'block', 
                                'blockcampaign', 
                                'exclude', 
                                'mmm_fo', 
        
                                // found in al.php
                                'layerstyle',
                                
                                // found in apu.php
                                'left',
                                'top',
                                'popunder',
                                'timeout',
                                'delay',
                                'toolbars',
                                'location',
                                'menubar',
                                'status',
                                'resizable',
                                'scrollbars',
                                
                                // used in fc.php
                                'script',
        
                                // found in tjs.php
                                'trackerid', 
                                'inherit', 
                                'append',
                                
                                // found in spc.php
                                'zones',
                                'block', 
                                'blockcampaign', 
                                'exclude', 
                                'mmm_fo', 
                                'nz',
        );
        /*
        // Print the human readable list of reserved variable 
        // See the list in https://developer.openx.org/wiki/display/Hosted/Lwes+Plugin
        $coreVarNames = array_merge($knownOpenXVarNames, $otherVarNames); 
        $coreVarNames = array_unique($coreVarNames);
        sort($coreVarNames);
        echo implode(", ", $coreVarNames);
        */
        
        $knownVarNames = array_merge($knownOpenXVarNames, $pluginVarNames, $otherVarNames);

        $varNamesInUrl = array_keys($_GET);
        $customVarNamesInUrl = array_diff($varNamesInUrl, $knownVarNames);
        
        $customVarNamesAndValues = array();
        foreach($customVarNamesInUrl as $name) {
            $customVarNamesAndValues[$name] = $_GET[$name];
        }
        
        $customVarNamesAndValuesFiltered = OX_Delivery_Common_hook('filterCustomVariables', array($customVarNamesAndValues), 'Plugin_deliveryLog_OxLogLwes_filterCustomVariables');
        if(!is_null($customVarNamesAndValuesFiltered)) {
            $customVarNamesAndValues = $customVarNamesAndValuesFiltered;
        }
        return $customVarNamesAndValues;
    }
    
    /**
     * In the case where Request and Impression are triggered in the same http request,
     * eg. in the case of the no cookie image tag
     * then we read the persisted id set during Request from GLOBALS 
     * In other cases, we read these parameters from the request parameters
     */
    function Plugin_deliveryLog_OxLogLwes_getEventIdTimestampFromUrlOrGlobals() {
        $e_hox_trax_id = '';
        if(isset($GLOBALS['_MAX']['OxLogLwes'][VARIABLE_REQUEST_ID])) {
            $e_hox_trax_id = $GLOBALS['_MAX']['OxLogLwes'][VARIABLE_REQUEST_ID];
        } elseif(isset($_REQUEST[VARIABLE_REQUEST_ID])) {
            $e_hox_trax_id = $_REQUEST[VARIABLE_REQUEST_ID];
        }
        
        $e_hox_trax_time = '';
        if(isset($GLOBALS['_MAX']['OxLogLwes'][VARIABLE_REQUEST_TIMESTAMP])) {
            $e_hox_trax_time = MAX_commonUnCompressInt($GLOBALS['_MAX']['OxLogLwes'][VARIABLE_REQUEST_TIMESTAMP]);
        } elseif(isset($_REQUEST[VARIABLE_REQUEST_TIMESTAMP])) {
            $e_hox_trax_time = MAX_commonUnCompressInt($_REQUEST[VARIABLE_REQUEST_TIMESTAMP]);
        } 
        
        if(empty($e_hox_trax_time)
            // timestamp of Jan, 1st, 2009 first date where we ever expect events ( mktime(0, 0, 0, 1, 1, 2009);)
            || (int)$e_hox_trax_time < 1230789600 ) 
        {
            if($GLOBALS['_MAX']['CONF']['oxLogLwes']['debug']) {
                echo "Discarding event because r_ts is empty, or is a timestamp before 2009, which is not expected";
            }
            return false;
        }
        return array(
            'e_hox_trax_id'    => $e_hox_trax_id,
            'e_hox_trax_time' => $e_hox_trax_time,
        );
    }
    
    function Plugin_deliveryLog_getExtraJsonVariables() 
    {
        // https://developer.openx.org/jira/browse/PRE-987
        // The hrid parameter will be set from the openx market plugin and will consist of the e_hox_trax_id 
        // and the e_hox_trax_time concatenated with a hyphen, eg: e_hox_trax_id-e_hox_trax_time. The brokers 
        // will split this string into the two fields e_hox_trax_id and e_hox_trax_time and set them in the LWES 
        // events. These two fields will be used to join HOX and Market events on the grid for various tasks.
        $eventIds = Plugin_deliveryLog_OxLogLwes_getEventIdTimestampFromUrlOrGlobals();
        return array(
            'hrid' => $eventIds['e_hox_trax_id'] .'-'. $eventIds['e_hox_trax_time']
        ); 
    }
    
    function Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_logRequest($creativeId, $zoneId, $aAd)
    {
        Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_init();

        $GLOBALS['_MAX']['OxLogLwes'][VARIABLE_REQUEST_ID] = md5(uniqid('', true));
        $GLOBALS['_MAX']['OxLogLwes'][VARIABLE_REQUEST_TIMESTAMP] = MAX_commonCompressInt(MAX_commonGetTimeNow());
        $data = array (
            'e_hox_trax_id'        => $GLOBALS['_MAX']['OxLogLwes'][VARIABLE_REQUEST_ID],
            'e_hox_trax_time'    => MAX_commonUnCompressInt($GLOBALS['_MAX']['OxLogLwes'][VARIABLE_REQUEST_TIMESTAMP]),

            'a_creative_localid'        => $creativeId,
            'a_campaign_localid'        => $aAd['campaign_id'],
            'a_advertiser_localid'        => $aAd['client_id'],
            'p_site_localid'            => @$aAd['affiliate_id'],
            'p_agency_localid'            => $aAd['agency_id'],
            'a_camp_freq_cap'            => $aAd['block_campaign'],
        
            'p_zone_id'            => $zoneId,
            'p_ad_width'        => $aAd['width'],
            'p_ad_height'        => $aAd['height'],
        
            'u_page_url'    => !empty($GLOBALS['loc']) ? $GLOBALS['loc'] : '',
            'u_ox_refer_url'=> !empty($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '',
        );
        
        // Add the custom fields in the event, making sure they are truncated, keep the first keys only, etc.
        $customVarsFromUrl = Plugin_deliveryLog_OxLogLwes_getCustomVarsFromUrl();
        if(!empty($customVarsFromUrl)) {
            // natural-sort the custom variables by their key name, then keep only the MAX first keys
            $customVarNames = array_keys($customVarsFromUrl);
            natsort($customVarNames);
            $countCustomVarBeforeTruncation = count($customVarNames);
            $customVarNames = array_slice($customVarNames, 0, MAXIMUM_CUSTOM_VARIABLES_IN_EVENT);
            $countTruncatedCustomVar = $countCustomVarBeforeTruncation - MAXIMUM_CUSTOM_VARIABLES_IN_EVENT;

            $i = 0;
            foreach($customVarNames as $name) {
                $i++;
                $data['p_opt'.$i.'_name'] = $name;
                $customVarValue = $customVarsFromUrl[$name];
                if(strlen($customVarValue) > MAXIMUM_LENGTH_CUSTOM_VARIABLE_VALUE) {
                    $customVarValue = substr($customVarValue, 0, MAXIMUM_LENGTH_CUSTOM_VARIABLE_VALUE-1) . "*";
                }
                $data['p_opt'.$i.'_value'] = $customVarValue;
            }
            if($countTruncatedCustomVar > 0) {
                $data['p_opt_truncated'] = $countTruncatedCustomVar;
            }
        }
        $GLOBALS['_MAX']['OxLogLwes']['lwes']->dispatch('Response', null, $data);
    }

    function Plugin_deliveryLog_oxLogLwes_logLwes_Delivery_postAdSelect(&$output) 
    {
      if (!isset ($GLOBALS['_MAX']['considered_ads']))
      {
        if ($GLOBALS['_MAX']['CONF']['oxLogLwes']['debug'])
        {
          echo "No considered_ads list in GLOBALS";
        }
        return;
      }


        $cp_ad_chosen = false;
        $selected_banner_id = $output['bannerid'];
        $considered_ad_ids = array();

        foreach ($GLOBALS['_MAX']['considered_ads'] as $aAds)
        {
            // First check to see if a higher priority campaign won, such as
            // exclusive or cAds, clAds.  If so, we're done since the contract
            // campaigns are not to be considered qualified if the higher
            // priority campaign type is winning

            if (isset ($aAds['xAds'][$selected_banner_id]))
            {
              return;
            }
            if (!empty ($aAds['cAds']))
            {
              foreach ($aAds['cAds'] as $c => $ads)
              {
                if (isset ($ads[$selected_banner_id]))
                {
                  return;
                }
              }
            }
            if (isset ($aAds['clAds'][$selected_banner_id]))
            {
              return;
            }

            // Now lets look at the contract campaigns
            if (!empty ($aAds['ads']))
            {
                foreach ($aAds['ads'] as $c => $ads)
                {
                    foreach ($ads as $id => $a)
                    {
                        // take note if a priority campaign's banner won.  also, do
                        // not include this in the list of considered ads
                        if ($id == $selected_banner_id)
                        {
                            $cp_ad_chosen = true;
                        }
                        else
                        {
                            $considered_ad_ids[] = $id;
                        }
                    }
                }
            }
        }

        // we only want to emit if the considered ads set is non-empty OR the
        // the winning banner is from a priority campaign.  These are not
        // mutually exclusive.  If the winning banner is not from a priority
        // campaign, just set the winning ad id to 0, since we only want to
        // look at priority campaigns.
        if ($cp_ad_chosen || count ($considered_ad_ids) > 0)
        {
            Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_logBannerList
                ($cp_ad_chosen ? $selected_banner_id : 0,
                 $output['aRow']['zoneid'],
                 $output['aRow'],
                 $considered_ad_ids);
        }
    }
    
    function Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_logBannerList($creativeId, $zoneId, &$aAd, &$qualAdIds)
    {
          Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_init();

          $data = array (
              'a_creative_localid'      => $creativeId,
          );
          
          if(!is_null($zoneId)) 
          {
              $data['a_campaign_localid'] = $aAd['campaign_id'];
              $data['a_advertiser_localid'] = $aAd['client_id'];
              $data['p_site_localid'] = @$aAd['affiliate_id'];
              $data['p_agency_localid'] = $aAd['agency_id'];
              $data['a_camp_freq_cap'] = $aAd['block_campaign'];
          }
          if(!is_null($zoneId)) 
          {
              $data['p_zone_id'] = $zoneId;
          }
          $i = 1;
          foreach ($qualAdIds as $qualId) {
            $data['b'.$i++] = $qualId;
            if ($i > MAXIMUM_BANNERLIST_BANNERS) {
              break;
            }
          }

          $data['x_max_index'] = $i - 1;

          if (count ($qualAdIds) > MAXIMUM_BANNERLIST_BANNERS) {
            $data['x_ad_truncated'] = MAXIMUM_BANNERLIST_BANNERS - count ($qualAdIds);
          }

        $idAndTimestamp = Plugin_deliveryLog_OxLogLwes_getEventIdTimestampFromUrlOrGlobals();
        if($idAndTimestamp !== false) {
            $data = array_merge($data, $idAndTimestamp);
            $GLOBALS['_MAX']['OxLogLwes']['lwes']->dispatch('BannerList', null, $data);
        }
    }

    function Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_logImpression($creativeId, $zoneId)
    {
        Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_init();
        $data = array (
            'p_zone_id'                    => $zoneId,
        
            'a_creative_localid'        => $creativeId,
            'a_campaign_localid'        => $GLOBALS['campaignid'],
        
            // the page URL where the ad is shown
            'u_page_url'    => !empty($GLOBALS['loc']) ? $GLOBALS['loc'] : '',
        );
        
        // was the ad the image fallback from a rich media ad? 
        $fallbackVarName = $GLOBALS['_MAX']['CONF']['var']['fallBack'];
        if(isset($_REQUEST[$fallbackVarName]) && $_REQUEST[$fallbackVarName] == '1') {
            $data['x_media_fallbk'] = true;
        }
        
        $idAndTimestamp = Plugin_deliveryLog_OxLogLwes_getEventIdTimestampFromUrlOrGlobals();
        if($idAndTimestamp !== false) {
            $data = array_merge($data, $idAndTimestamp);
            $GLOBALS['_MAX']['OxLogLwes']['lwes']->dispatch('Impression', null, $data);
        }
        if($GLOBALS['_MAX']['CONF']['oxLogLwes']['debug']) {
            // we exit so that we can see the lwes output in the browser
            // in the case an header is sent to redirect to a image banner, eg. in the case of noscript image tag
            exit;
        }
    }
    
    function Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_logClick($creativeId, $zoneId)
    {
        Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_init();
        $data = array (
            'a_creative_localid'=> $creativeId,
            'a_campaign_localid'=> $GLOBALS['campaignid'],
            'p_zone_id'            => $zoneId,

            'a_click_url'        => $_REQUEST['oadest'],
        
            // the page URL where the ad is shown and was clicked on
            'u_page_url'    => !empty($GLOBALS['loc']) ? $GLOBALS['loc'] : '',
          
        );
        $idAndTimestamp = Plugin_deliveryLog_OxLogLwes_getEventIdTimestampFromUrlOrGlobals();
        if($idAndTimestamp !== false) {
            $data = array_merge($data, $idAndTimestamp);
            $GLOBALS['_MAX']['OxLogLwes']['lwes']->dispatch('Click', null, $data);
        }
        if($GLOBALS['_MAX']['CONF']['oxLogLwes']['debug']) {
            // we exit so that we can see the lwes output in the browser
            // rather than being redirected to the clicked URL 
            exit;
        }
    }
    
    function Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_logConversion($trackerId, $serverRawIp, $aConversion)
    {
        //currently, conversion event is not sent
        return;
        Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_init();
        $data = array(
            'server_ip_addr'              => $serverRawIp,
            'tracker_id'                  => $trackerId,
            'tracker_action_timestamp'    => $aConversion['dt'],
            'tracker_creative_id'         => $aConversion['cid'],
            'tracker_zone_id'             => $aConversion['zid'],
            'tracker_action_type'         => $aConversion['action_type'],
            'tracker_window'              => $aConversion['window'],
            'tracker_status'              => $aConversion['status']
        );
        $GLOBALS['_MAX']['OxLogLwes']['lwes']->dispatch('Conversion', null, $data);
    }
    
    function Plugin_deliveryLog_OxLogLwes_logLwes_Delivery_logConversionVariable($aVariables, $trackerId, $serverConvId, $serverRawIp)
    {
        //currently, conversion event is not sent
        return;
    }
    
    // we persist the request id and timestamp across events
    function Plugin_deliveryLog_oxLogLwes_logLwes_Delivery_addUrlParams($aBanner = array())
    {
        $aVars = array(VARIABLE_REQUEST_ID, VARIABLE_REQUEST_TIMESTAMP);
        
        $aReturn = array();
        foreach ($aVars as $key) {
            if (!empty($GLOBALS['_MAX']['OxLogLwes'][$key])) {
                $aReturn[$key] = $GLOBALS['_MAX']['OxLogLwes'][$key];
            } elseif (!empty($_REQUEST[$key])) {
                $aReturn[$key] = $_REQUEST[$key];
            } else {
                $aReturn[$key] = false;
            }
        }
        return $aReturn;
    }
    
    function LogLwes_getCookiesToSetInEvent()
    {
        if(empty($GLOBALS['LogLwesCookies']) || !is_array($GLOBALS['LogLwesCookies'])) {
            $GLOBALS['LogLwesCookies'] = array();
        }
        $cookies = $GLOBALS['LogLwesCookies'];
        if(isset($GLOBALS['_MAX']['CONF']['oxLogLwes']['cookiesToSetInEvents'])) {
            $cookiesFromSettings = explode(',', $GLOBALS['_MAX']['CONF']['oxLogLwes']['cookiesToSetInEvents']);
            $cookies = array_merge($cookiesFromSettings, $cookies);
        }
        return array_unique(array_map('trim', $cookies)); 
    }
}
