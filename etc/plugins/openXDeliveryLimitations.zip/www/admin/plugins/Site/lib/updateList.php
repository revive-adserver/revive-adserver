<?php

echo "<script type=\"text/javascript\" src=\"plugins/Site/js/updateList.js\"></script>";
