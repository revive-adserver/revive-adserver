<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$RV_Geo_Continent = [
    'AF' => 'Africa',
    'AQ' => 'Antartica',
    'AS' => 'Asia',
    'CA' => 'Caribbean',
    'EU' => 'Europe',
    'NA' => 'North America',
    'OC' => 'Australia/Oceania',
    'SA' => 'South America',
];
