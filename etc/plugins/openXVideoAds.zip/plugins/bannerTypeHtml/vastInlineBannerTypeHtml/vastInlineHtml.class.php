<?php

/*    
 *    Copyright (c) 2009 Bouncing Minds - Option 3 Ventures Limited
 *
 *    This file is part of the Regions plug-in for Flowplayer.
 *
 *    The Regions plug-in is free software: you can redistribute it 
 *    and/or modify it under the terms of the GNU General Public License 
 *    as published by the Free Software Foundation, either version 3 of 
 *    the License, or (at your option) any later version.
 *
 *    The Regions plug-in is distributed in the hope that it will be 
 *    useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with the plug-in.  If not, see <http://www.gnu.org/licenses/>.
 */

require_once MAX_PATH . '/plugins/bannerTypeHtml/vastInlineBannerTypeHtml/common.php';
require_once MAX_PATH . '/plugins/bannerTypeHtml/vastInlineBannerTypeHtml/commonAdmin.php';

require_once MAX_PATH . '/lib/OA.php';
require_once LIB_PATH . '/Extension/bannerTypeHtml/bannerTypeHtml.php';
require_once MAX_PATH . '/lib/max/Plugin/Common.php';

/**
 *
 * @package    OpenXPlugin
 * @subpackage Plugins_BannerTypes
 * @author     Paul Birnie <paul.birnie@bouncingminds.com>
 * @abstract
 */
class Plugins_BannerTypeHTML_vastInlineBannerTypeHtml_vastInlineHtml extends Plugins_BannerTypeHTML_vastInlineBannerTypeHtml_vastBase
{

    /**
     * Return description of banner type
     * for the dropdown selection on the banner-edit screen
     *
     * @return string A string describing the type of plugin.
     */
    function getOptionDescription()
    {
        return $this->translate('OpenX VAST Inline Video Banner (pre/mid/post-roll)');
    }

    /**
     * Append type-specific form elements to the base form
     *
     * @param object form
     * @param integer bannerId
     */
    function buildForm(&$form, &$bannerRow)
    {   
    	$selectableCompanions = $this->getPossibleCompanions();   	
    	
    	// for some bizarre reason $bannerid is all the fields 
    	$bannerRow = $this->getExtendedBannerInfo($bannerRow);
    	
        $isNewBanner = false;

        if ( !isset( $bannerRow['banner_vast_element_id']) ){
            
            $isNewBanner = true;
        }

        //parent::buildForm($form, $bannerId);
        $header = $form->createElement('header', 'header_txt', "Create a inline video banner (pre/mid/post-roll)");
        $header->setAttribute('icon', 'icon-banner-text.gif');
        $form->addElement($header);

        /* Not applicable to a VAST inline banner 
        $form->addElement('header', 'header_b_links', "Banner link");
        $form->addElement('text', 'url', $GLOBALS['strURL']);
        $form->addElement('text', 'target', $GLOBALS['strTarget']);
        */

        $form->addElement('hidden', 'ext_bannertype', $this->getComponentIdentifier());
        
        
        // Now the zone matching dimensions - this is a hack until we have a callback hook 
        // isZoneCompatibleWithBanner() or something like that.
        /*
        $form->addElement('header', 'matching_zone_dimensions', "Zone Matching Dimensions");        
        
        $form->addElement('static', 'zoneinfo', "(These must be the same as the height and width of the zone)");
        
        $form->addElement('text', 'width', "Width");
        $form->addElement('text', 'height', "Height");   
             
        */
        addVastHardcodedDimensionsToForm($form, $bannerRow, VAST_INLINE_DIMENSIONS);
 
        
        // ----- Now the VIDEO status
        $form->addElement('header', 'video_status', "VAST video parameters"); 
              
        $isVideoUploadSupported = false;
        
        if ($isVideoUploadSupported){
     
            addUploadGroup($form, $row,
                array(
                    'uploadName' => 'uploadalt',
                    'radioName' => 'replacealtimage',
                    'imageName'  => $altImageName,
                    'fileSize'  => $altSize,
                    'fileName'  => $row['alt_filename'],
                    'newLabel'  => "select incomming video file",
                    'updateLabel'  => "select replacement video file",
                    'handleSWF' => false
                  )
            );
        }
        
        addVastParametersToForm($form, $bannerRow, $isNewBanner);
        addVastCompanionsToForm($form, $selectableCompanions);
    }

    function onEnable()
    {
        $oSettings  = new OA_Admin_Settings();
        $oSettings->settingChange('allowedBanners','video','1');
        $oSettings->writeConfigChange();
        return true;
    }
}
?>
