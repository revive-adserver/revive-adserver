<?php

class y_axis_right extends y_axis_base
{
	function __construct(){}
}