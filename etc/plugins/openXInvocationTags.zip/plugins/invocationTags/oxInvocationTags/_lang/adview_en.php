<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$words = array(
    'Image Tag' => 'Image Tag',
    'Allow Image Tags' => 'Allow Image Tags',
    'SSL Backup Comment' => '',
    'Comment' => "
  * This tag only shows image banners. There is no width or height in
  * these banners, so if you want these tags to allocate space for the
  * ad before it shows, you will need to add this information to the
  * <img> tag.",
    'Third Party Comment' => '',
);

?>
