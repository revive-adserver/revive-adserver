<?php

/**
 * OX-specific submit button.
 */
class OX_UI_Form_Element_Button extends Zend_Form_Element_Button
{
    protected $class = "inline";
}