<?php

/**
 * Defines an element that needs and inline JavaScript to work
 */
interface OX_UI_Form_Element_WithInlineScript
{
    public function getInlineScript();
}
