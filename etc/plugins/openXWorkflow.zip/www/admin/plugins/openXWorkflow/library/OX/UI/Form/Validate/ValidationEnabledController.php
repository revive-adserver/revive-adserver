<?php

/**
 * 
 */
interface OX_UI_Form_Validate_ValidationEnabledController
{
    public function isValidationEnabled($value, $context);
}
