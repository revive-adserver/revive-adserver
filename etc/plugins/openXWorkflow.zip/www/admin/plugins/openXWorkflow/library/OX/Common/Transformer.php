<?php

interface OX_Common_Transformer
{
    function transform($o1);
}

?>
