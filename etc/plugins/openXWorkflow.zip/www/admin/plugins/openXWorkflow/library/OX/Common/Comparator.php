<?php

interface OX_Common_Comparator
{
    function compare($o1, $o2);
}

?>
