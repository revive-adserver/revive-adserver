<?php // $Revision: 1.12 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2001 by the phpAdsNew developers                       */
/* http://sourceforge.net/projects/phpadsnew                            */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


// Set text direction and characterset
$GLOBALS['phpAds_TextDirection']  = "ltr";
$GLOBALS['phpAds_TextAlignRight'] = "right";
$GLOBALS['phpAds_TextAlignLeft']  = "left";


// Set translation strings
$GLOBALS['strHome'] = "Hjem";
$GLOBALS['date_format'] = "%d/%m/%Y";
$GLOBALS['time_format'] = "%H:%i:%S";
$GLOBALS['strMySQLError'] = "MySQL-Error:";
$GLOBALS['strAdminstration'] = "Administrasjon";
$GLOBALS['strAddClient'] = "Legg til ny klient";
$GLOBALS['strModifyClient'] = "Endre klient";
$GLOBALS['strDeleteClient'] = "Slett klient";
$GLOBALS['strViewClientStats'] = "Vis statistikk for klient";
$GLOBALS['strClientName'] = "Klient";
$GLOBALS['strContact'] = "Kontakt";
$GLOBALS['strEMail'] = "Epost";
$GLOBALS['strViews'] = "Bannervisninger";
$GLOBALS['strClicks'] = "Bannerklikk";
$GLOBALS['strTotalViews'] = "Bannervisninger totalt";
$GLOBALS['strTotalClicks'] = "Bannerklikk totalt";
$GLOBALS['strCTR'] = "GjennomKlikksForhold";
$GLOBALS['strTotalClients'] = "Klienter totalt";
$GLOBALS['strActiveClients'] = "Aktive klienter";
$GLOBALS['strActiveBanners'] = "Aktive bannere";
$GLOBALS['strLogout'] = "Logg ut";
$GLOBALS['strCreditStats'] = "Credit Stats";
$GLOBALS['strViewCredits'] = "Bannervisninger credits";
$GLOBALS['strClickCredits'] = "Bannerklikk credits";
$GLOBALS['strPrevious'] = "Forrige";
$GLOBALS['strNext'] = "Neste";
$GLOBALS['strNone'] = "Ingen";
$GLOBALS['strViewsPurchased'] = "Bannervisninger kj�pt";
$GLOBALS['strClicksPurchased'] = "Bannerklikk kj�pt";
$GLOBALS['strDaysPurchased'] = "Bannerdager kj�pt";
$GLOBALS['strHTML'] = "HTML";
$GLOBALS['strAddSep'] = "Fyll ENTEN inn feltene ovenfor, ELLER feltet nedenfor!";
$GLOBALS['strTextBelow'] = "Tekst under bildet";
$GLOBALS['strSubmit'] = "Lagre banner";
$GLOBALS['strUsername'] = "Brukernavn";
$GLOBALS['strPassword'] = "Passord";
$GLOBALS['strBannerAdmin'] = "Banner administrasjon for";
$GLOBALS['strNoBanners'] = "Ingen bannere funnet";
$GLOBALS['strBanner'] = "Banner";
$GLOBALS['strCurrentBanner'] = "Gjeldende banner";
$GLOBALS['strDelete'] = "Slett";
$GLOBALS['strAddBanner'] = "Legg til ny banner";
$GLOBALS['strModifyBanner'] = "Endre banner";
$GLOBALS['strURL'] = "Linket til URL (inkludert http://)";
$GLOBALS['strKeyword'] = "Stikkord";
$GLOBALS['strWeight'] = "Vekt";
$GLOBALS['strAlt'] = "Alt-Tekst";
$GLOBALS['strAccessDenied'] = "Tilgang nektet";
$GLOBALS['strPasswordWrong'] = "Passordet er ikke riktig";
$GLOBALS['strNotAdmin'] = "Du har muligens ikke rettigheter til denne operasjonen";
$GLOBALS['strClientAdded'] = "Klienten er blitt lagt til";
$GLOBALS['strClientModified'] = "Klienten har blitt endret";
$GLOBALS['strClientDeleted'] = "Klienten har blitt slettet";
$GLOBALS['strBannerAdmin'] = "Banner Administrasjon";
$GLOBALS['strBannerAdded'] = "Banneret har blitt lagt til";
$GLOBALS['strBannerModified'] = "Banneret har blitt endret";
$GLOBALS['strBannerDeleted'] = "Banneret har blitt slettet";
$GLOBALS['strBannerChanged'] = "Banneret har blitt endret";
$GLOBALS['strStats'] = "Statistikk";
$GLOBALS['strDailyStats'] = "Daglig statistikk";
$GLOBALS['strDetailStats'] = "Detaljert statistikk";
$GLOBALS['strCreditStats'] = "Credit statistics";
$GLOBALS['strActive'] = "aktiv";
$GLOBALS['strActivate'] = "Aktiver";
$GLOBALS['strDeActivate'] = "Deaktiver";
$GLOBALS['strAuthentification'] = "Autentifikasjon";
$GLOBALS['strGo'] = "Go";
$GLOBALS['strLinkedTo'] = "linket til";
$GLOBALS['strBannerID'] = "Banner-ID";
$GLOBALS['strClientID'] = "Klient ID";
$GLOBALS['strMailSubject'] = "Banner rapport";
$GLOBALS['strMailSubjectDeleted'] = "Deaktiverte bannere";
$GLOBALS['strMailHeader'] = "Kj�re {contact},\n";
$GLOBALS['strMailBannerStats'] = "Under vil du finne klientstatistikk for {clientname}:";
$GLOBALS['strMailFooter'] = "Med vennlig hilsen,\n   {adminfullname}";
$GLOBALS['strLogMailSent'] = "[phpAds] Statistikk sendt.";
$GLOBALS['strLogErrorClients'] = "[phpAds] En feil oppstod under henting av klienter fra databasen.";
$GLOBALS['strLogErrorBanners'] = "[phpAds] En feil oppstod under henting av bannere fra databasen.";
$GLOBALS['strLogErrorViews'] = "[phpAds] En feil oppstod under henting av bannervisninger fra databasen.";
$GLOBALS['strLogErrorClicks'] = "[phpAds] En feil oppstod under henting av bannerklikk fra databasen.";
$GLOBALS['strLogErrorDisactivate'] = "[phpAds] En feil oppstod under deaktivering av banner.";
$GLOBALS['strRatio'] = "GjennomKlikksForhold";
$GLOBALS['strChooseBanner'] = "Vennligst velg type banner.";
$GLOBALS['strMySQLBanner'] = "Banner lagret i databasen (MySQL)";
$GLOBALS['strWebBanner'] = "Banner lagret p� webserver";
$GLOBALS['strURLBanner'] = "Banner referert til via URL";
$GLOBALS['strHTMLBanner'] = "HTML banner";
$GLOBALS['strNewBannerFile'] = "Ny bannerfil";
$GLOBALS['strNewBannerURL'] = "Ny banner URL (inkludert http://)";
$GLOBALS['strWidth'] = "Vidde";
$GLOBALS['strHeight'] = "H�yde";
$GLOBALS['strTotalViews7Days'] = "Totalt ant bannervisninger siste 7 dager";
$GLOBALS['strTotalClicks7Days'] = "Totalt ant bannerklikk siste 7 dager";
$GLOBALS['strAvgViews7Days'] = "Gjennomsnittlig ant bannervisninger siste 7 dager";
$GLOBALS['strAvgClicks7Days'] = "Gjennomsnittlig ant bannerklikk siste 7 dager";
$GLOBALS['strTopTenHosts'] = "Top ti \"reklameinteresserte\" tjenere";
$GLOBALS['strClientIP'] = "Klient IP";
$GLOBALS['strUserAgent'] = "User agent regexp";
$GLOBALS['strWeekDay'] = "Ukedag (0 - 6)";
$GLOBALS['strDomain'] = "Domene (uten punktum)";
$GLOBALS['strSource'] = "Kilde";
$GLOBALS['strTime'] = "Tid";
$GLOBALS['strAllow'] = "Tillat";
$GLOBALS['strDeny'] = "Nekt";
$GLOBALS['strResetStats'] = "Tilbakestill statistikk";
$GLOBALS['strExpiration'] = "Utl�psdato";
$GLOBALS['strNoExpiration'] = "Ingen utl�psdato angitt";
$GLOBALS['strDaysLeft'] = "Dager igjen";
$GLOBALS['strEstimated'] = "Estimert utl�p";
$GLOBALS['strConfirm'] = "Er du sikker ?";
$GLOBALS['strBannerNoStats'] = "Ingen statistikk tilgjengelig for dette banneret!";
$GLOBALS['strWeek'] = "Uke";
$GLOBALS['strWeeklyStats'] = "Ukentlig statistikk";
$GLOBALS['strWeekDay'] = "Ukedag";
$GLOBALS['strDate'] = "Dato";
$GLOBALS['strCTRShort'] = "GKF";
$GLOBALS['strDayShortCuts'] = array("S�","Ma","Ti","On","To","Fr","L�");
$GLOBALS['strShowWeeks'] = "Maks uker � vise";
$GLOBALS['strAll'] = "alle";
$GLOBALS['strAvg'] = "Gj.sn.";
$GLOBALS['strHourly'] = "Visninger/klikk per time";
$GLOBALS['strTotal'] = "Totalt";
$GLOBALS['strUnlimited'] = "Ubegrenset";
$GLOBALS['strSave'] = "Lagre";
$GLOBALS['strUp'] = "Opp";
$GLOBALS['strDown'] = "Ned";
$GLOBALS['strSaved'] = "ble lagert!";
$GLOBALS['strDeleted'] = "ble slettet!";
$GLOBALS['strMovedUp'] = "ble flyttet opp";
$GLOBALS['strMovedDown'] = "ble flyttet ned";
$GLOBALS['strUpdated'] = "ble oppdatert";
$GLOBALS['strLogin'] = "Logg inn";
$GLOBALS['strPreferences'] = "Egenskapger";
$GLOBALS['strAllowClientModifyInfo'] = "Tillat denne brukeren � endre sin egen klientinformasjon";
$GLOBALS['strAllowClientModifyBanner'] = "Tillat denne brukeren � endre sine egne bannere";
$GLOBALS['strAllowClientAddBanner'] = "Tillat denne brukeren � legge til egne bannere";
$GLOBALS['strLanguage'] = "Spr�k";
$GLOBALS['strDefault'] = "Standard";
$GLOBALS['strErrorViews'] = "Du m� velge antall visninger, eller velge ubegrenset !";
$GLOBALS['strErrorNegViews'] = "Negativt antall visninger er ikke tillatt";
$GLOBALS['strErrorClicks'] =  "Du m� velge antall klikk, eller velge ubegrenset !";
$GLOBALS['strErrorNegClicks'] = "Negativt antall klikk er ikke tillatt";
$GLOBALS['strErrorDays'] = "Du m� velge antall dager, eller velge ubegrenset !";
$GLOBALS['strErrorNegDays'] = "Negativt antall dager er ikke tillatt";
$GLOBALS['strTrackerImage'] = "Tracker bilde:";

// New strings for version 2
$GLOBALS['strNavigation'] 				= "Navigasjon";
$GLOBALS['strShortcuts'] 				= "Snarveier";
$GLOBALS['strDescription'] 				= "Beskrivelse";
$GLOBALS['strClients'] 					= "Klienter";
$GLOBALS['strID']				 		= "ID";
$GLOBALS['strOverall'] 					= "Totalt";
$GLOBALS['strTotalBanners'] 			= "Bannere totalt";
$GLOBALS['strToday'] 					= "I dag";
$GLOBALS['strThisWeek'] 				= "Denne uka";
$GLOBALS['strThisMonth'] 				= "Denne m�ndeden";
$GLOBALS['strBasicInformation'] 		= "Hovedinformasjon";
$GLOBALS['strContractInformation'] 		= "Kontraktsinformasjon";
$GLOBALS['strLoginInformation'] 		= "Logginn informasjon";
$GLOBALS['strPermissions'] 				= "Rettigheter";
$GLOBALS['strGeneralSettings']			= "Generelle innstillinger";
$GLOBALS['strSaveChanges']		 		= "Lagre endringer";
$GLOBALS['strCompact']					= "Kompakt";
$GLOBALS['strVerbose']					= "Verbose";
$GLOBALS['strOrderBy']					= "sorter etter";
$GLOBALS['strShowAllBanners']	 		= "Vis alle bannere";
$GLOBALS['strShowBannersNoAdClicks']	= "Vis bannere uten klikk";
$GLOBALS['strShowBannersNoAdViews']		= "Vis bannere uten visninger";
$GLOBALS['strShowAllClients'] 			= "Vis alle klienter";
$GLOBALS['strShowClientsActive'] 		= "Vis klienter med aktive bannere";
$GLOBALS['strShowClientsInactive']		= "Vis klienter med inaktive bannere";
$GLOBALS['strSize']						= "St�rrelse";

$GLOBALS['strMonth'] 					= array("Januar","Februar","Mars","April","Mai","Juni","Juli", "August", "September", "Oktober", "November", "Desember");
$GLOBALS['strDontExpire']				= "Ikke sett utl�p for denne kampanjen p� en bestemt dato";
$GLOBALS['strActivateNow'] 				= "Aktiver denne kampanjen �yeblikkelig";
$GLOBALS['strExpirationDate']			= "Utl�psdato";
$GLOBALS['strActivationDate']			= "Aktiveringsdato";

$GLOBALS['strMailClientDeactivated'] 	= "F�lgende bannere har blitt gjort ugyldige fordi";
$GLOBALS['strMailNothingLeft'] 			= "Hvis du �nsker � fortsette � reklamere p� v�re nettsider, ta gjerne kontakt.\nVi blir glade for � h�re fra deg!";
$GLOBALS['strClientDeactivated']		= "Denne kampanjen er for �yeblikket ikke aktiv fordi";
$GLOBALS['strBeforeActivate']			= "aktiveringsdatoen er enn� ikke n�dd";
$GLOBALS['strAfterExpire']				= "utl�psdatoen har blitt n�dd";
$GLOBALS['strNoMoreClicks']				= "antall kj�pte bannerklikk er brukt";
$GLOBALS['strNoMoreViews']				= "antall brukte bannervisninger er brukt";

$GLOBALS['strBanners'] 					= "Bannere";
$GLOBALS['strCampaigns']				= "Kampanjer";
$GLOBALS['strCampaign']					= "Kampanje";
$GLOBALS['strModifyCampaign']			= "Endre kampanje";
$GLOBALS['strName']						= "Navn";
$GLOBALS['strBannersWithoutCampaign']	= "Bannere uten kampanjer";
$GLOBALS['strMoveToNewCampaign']		= "Flytt til en ny kampanje";
$GLOBALS['strCreateNewCampaign']		= "Lag ny kampanje";
$GLOBALS['strEditCampaign']				= "Endre kampanje";
$GLOBALS['strEdit']						= "Endre";
$GLOBALS['strCreate']					= "Lag";
$GLOBALS['strUntitled']					= "Ingen tittel";

$GLOBALS['strTotalCampaigns'] 			= "Kampanjer totalt";
$GLOBALS['strActiveCampaigns'] 			= "Aktive kampanjer";

$GLOBALS['strLinkedTo']					= "linket til";
$GLOBALS['strSendAdvertisingReport']	= "Send en banner rapport via epost";
$GLOBALS['strNoDaysBetweenReports']		= "Antall dager mellom rapportene";
$GLOBALS['strSendDeactivationWarning']  = "Send melding n�r en kampanje er blitt deaktivert";

$GLOBALS['strWarnClientTxt']			= "Antall klikk og visninger igjen for din(e) banner(e) er p� vei under {limit}. \nDin(e) banner(e) vil bli gjort ugyldige n�r det ikke er noen klikk eller visninger igjen. ";
$GLOBALS['strViewsClicksLow']			= "Antall banner visninger/klikk er lavt";

$GLOBALS['strDays']						= "Dager";
$GLOBALS['strHistory']					= "Historie";
$GLOBALS['strAverage']					= "Gjennomsnitt";
$GLOBALS['strDuplicateClientName']		= "Brukernavnet du valgte eksisterer allerede. Vennligst velg et annet brukernavn.";
$GLOBALS['strAllowClientDisableBanner'] = "Tillat denne brukeren � deaktivere sine egne bannere";
$GLOBALS['strAllowClientActivateBanner'] = "Tillat denne brukeren � aktivere sine egne bannere";

$GLOBALS['strGenerateBannercode']		= "Generer bannerkode";
$GLOBALS['strChooseInvocationType']		= "Vennlig velg type for banner utvelgelse";
$GLOBALS['strGenerate']					= "Generer";
$GLOBALS['strParameters']				= "Parametre";
$GLOBALS['strUniqueidentifier']			= "Unik identifikasjon";
$GLOBALS['strFrameSize']				= "Rammest�rrelse";
$GLOBALS['strBannercode']				= "Bannerkode";

$GLOBALS['strSearch']					= "S�k";
$GLOBALS['strNoMatchesFound']			= "Ingen treff";

$GLOBALS['strNoViewLoggedInInterval']   = "Ingen visninger ble logget innenfor perioden for denne rapporten";
$GLOBALS['strNoClickLoggedInInterval']  = "Ingen klikk ble logget innenfor perioden for denne rapporten";
$GLOBALS['strMailReportPeriod']			= "Denne rapporten inneholder statistikk fra {startdate} til {enddate}.";
$GLOBALS['strMailReportPeriodAll']		= "Denne rapporten inneholder all statistikk til {enddate}.";
$GLOBALS['strNoStatsForCampaign'] 		= "Det er ikke noe statistikk tilgjengelig for denne kampanjen";
$GLOBALS['strFrom']						= "Fra";
$GLOBALS['strTo']						= "til";
$GLOBALS['strMaintenance']				= "Vedlikehold";
$GLOBALS['strCampaignStats']			= "Kampanjestatistikk";
$GLOBALS['strClientStats']				= "Klientstatistikk";
$GLOBALS['strErrorOccurred']			= "En feil oppstod";
$GLOBALS['strAdReportSent']				= "Annonseringsrapport er sendt";

$GLOBALS['strAutoChangeHTML']			= "Endre HTML for � logge klikk";

$GLOBALS['strZones']					= "Soner";
$GLOBALS['strAddZone']					= "Lag sone";
$GLOBALS['strModifyZone']				= "Endre sone";
$GLOBALS['strAddNewZone']				= "Legg til ny sone";

$GLOBALS['strOverview']					= "Overblikk";
$GLOBALS['strEqualTo']					= "er lik";
$GLOBALS['strDifferentFrom']			= "er ulik";
$GLOBALS['strAND']						= "AND";  // logical operator
$GLOBALS['strOR']						= "OR"; // logical operator
$GLOBALS['strOnlyDisplayWhen']			= "Vis dette banneret bare n�r:";

$GLOBALS['strStatusText']				= "Status Tekst";

$GLOBALS['strConfirmDeleteClient'] 		= "Vil du virkelig slette denne klienten?";
$GLOBALS['strConfirmDeleteCampaign']	= "Vil du virkelig slette denne kampanjen?";
$GLOBALS['strConfirmDeleteBanner']		= "Vil du virkelig slette dette banneret?";
$GLOBALS['strConfirmDeleteZone']		= "Do you really want to delete this zone?";
$GLOBALS['strConfirmDeleteAffiliate']	= "Do you really want to delete this affiliate?";

$GLOBALS['strConfirmResetStats']		= "Vil du virkelig tilbakestille/slette all statistikk?";
$GLOBALS['strConfirmResetCampaignStats']= "Vil du virkelig tilbakestille/slette statistikken for denne kampanjen?";
$GLOBALS['strConfirmResetClientStats']	= "Vil du virkelig tilbakestille/slette statistikken for denne klienten?";
$GLOBALS['strConfirmResetBannerStats']	= "Vil du virkelig tilbakestille/slette statistikken for dette banneret?";

$GLOBALS['strClientsAndCampaigns']		= "Klienter & kampanjer";
$GLOBALS['strCampaignOverview']			= "Kampanje overblikk";
$GLOBALS['strReports']					= "Rapporter";
$GLOBALS['strShowBanner']				= "Vis banner";

$GLOBALS['strIncludedBanners']			= "Linkede bannere";
$GLOBALS['strProbability']				= "Sannsynlighet";
$GLOBALS['strInvocationcode']			= "Inndragelseskode";
$GLOBALS['strSelectZoneType']			= "Vennligst velg type linkede bannere";
$GLOBALS['strBannerSelection']			= "Banner valg";
$GLOBALS['strInteractive']				= "Ineraktiv";
$GLOBALS['strRawQueryString']			= "Ren sp�rrestreng";

$GLOBALS['strBannerWeight']				= "Banner vekt";
$GLOBALS['strCampaignWeight']			= "Kampanje vekt";

$GLOBALS['strZoneCacheOn']				= "Sone caching/bufring er sl�tt p�";
$GLOBALS['strZoneCacheOff']				= "Sone caching/bufring er sl�tt av";
$GLOBALS['strCachedZones']				= "Cachede/Bufrede soner";
$GLOBALS['strSizeOfCache']				= "St�rrelse p� cache/buffer";
$GLOBALS['strAverageAge']				= "Gjennomsnittlig alder";
$GLOBALS['strRebuildZoneCache']			= "Gjenopprett sone cache/buffer";
$GLOBALS['strKiloByte']					= "KB";
$GLOBALS['strSeconds']					= "sekunder";
$GLOBALS['strExpired']					= "Utl�pt";

$GLOBALS['strModifyBannerAcl'] 			= "Display limitations";
$GLOBALS['strACL'] 						= "Limit";
$GLOBALS['strNoMoveUp'] 				= "Kan ikke flyttet til f�rste rad";
$GLOBALS['strACLAdd'] 					= "Add new limitation";
$GLOBALS['strNoLimitations']			= "No limitations";

$GLOBALS['strLinkedZones']				= "Linked Zones";
$GLOBALS['strNoZonesToLink']			= "There are no zones available to which this banner can be linked";
$GLOBALS['strNoZones']					= "There are currently no zones defined";
$GLOBALS['strNoClients']				= "There are currently no clients defined";
$GLOBALS['strNoStats']					= "There are currently no statistics available";
$GLOBALS['strNoAffiliates']				= "There are currently no affiliates defined";

$GLOBALS['strCustom']					= "Custom";

$GLOBALS['strSettings'] 				= "Settings";

$GLOBALS['strAffiliates']				= "Affiliates";
$GLOBALS['strAffiliatesAndZones']		= "Affiliates & Zones";
$GLOBALS['strAddAffiliate']				= "Create affiliate";
$GLOBALS['strModifyAffiliate']			= "Modify affiliate";
$GLOBALS['strAddNewAffiliate']			= "Add new affiliate";

$GLOBALS['strCheckAllNone']				= "Check all / none";

$GLOBALS['strAllowAffiliateModifyInfo'] = "Allow this user to modify his own affiliate information";
$GLOBALS['strAllowAffiliateModifyZones'] = "Allow this user to modify his own zones";
$GLOBALS['strAllowAffiliateLinkBanners'] = "Allow this user to link banners to his own zones";
$GLOBALS['strAllowAffiliateAddZone'] = "Allow this user to define new zones";
$GLOBALS['strAllowAffiliateDeleteZone'] = "Allow this user to delete existing zones";

$GLOBALS['strPriority']					= "Priority";
$GLOBALS['strHighPriority']				= "Show banners in this campaign with high priority.<br>
										   If you use this option phpAdsNew will try to distribute the 
										   number of AdViews evenly over the course of the day.";
$GLOBALS['strLowPriority']				= "Show banner in this campaign with low priority.<br>
										   This campaign is used to show the left over AdViews which 
										   aren't used by high priority campaigns.";
$GLOBALS['strTargetLimitAdviews']		= "Limit the number of AdViews to";
$GLOBALS['strTargetPerDay']				= "per day.";
$GLOBALS['strRecalculatePriority']		= "Recalculate priority";

$GLOBALS['strProperties']				= "Properties";
$GLOBALS['strAffiliateProperties']		= "Affiliate properties";
$GLOBALS['strBannerOverview']			= "Banner overview";
$GLOBALS['strBannerProperties']			= "Banner properties";
$GLOBALS['strCampaignProperties']		= "Campaign properties";
$GLOBALS['strClientProperties']			= "Client properties";
$GLOBALS['strZoneOverview']				= "Zone overview";
$GLOBALS['strZoneProperties']			= "Zone properties";
$GLOBALS['strAffiliateOverview']		= "Affiliate overview";
$GLOBALS['strLinkedBannersOverview']	= "Linked banners overview";

$GLOBALS['strGlobalHistory']			= "Global history";
$GLOBALS['strBannerHistory']			= "Banner history";
$GLOBALS['strCampaignHistory']			= "Campaign history";
$GLOBALS['strClientHistory']			= "Client history";
$GLOBALS['strAffiliateHistory']			= "Affiliate history";
$GLOBALS['strZoneHistory']				= "Zone history";
$GLOBALS['strLinkedBannerHistory']		= "Linked banner history";

$GLOBALS['strMoveTo']					= "Move to";
$GLOBALS['strDuplicate']				= "Duplicate";

$GLOBALS['strMainSettings']				= "Main settings";
$GLOBALS['strAdminSettings']			= "Administration settings";

$GLOBALS['strApplyLimitationsTo']		= "Apply limitations to";
$GLOBALS['strWholeCampaign']			= "Whole campaign";
$GLOBALS['strZonesWithoutAffiliate']	= "Zones without affiliate";
$GLOBALS['strMoveToNewAffiliate']		= "Move to new affiliate";

$GLOBALS['strNoBannersToLink']			= "There are currently no banners available which can be linked to this zone";
$GLOBALS['strNoLinkedBanners']			= "There are no banners available which are linked to this zone";

$GLOBALS['strAdviewsLimit']				= "AdViews limit";

$GLOBALS['strTotalThisPeriod']			= "Total this period";
$GLOBALS['strAverageThisPeriod']		= "Average this period";
$GLOBALS['strLast7Days']				= "Last 7 days";
$GLOBALS['strDistribution']				= "Distribution";
$GLOBALS['strOther']					= "Other";
$GLOBALS['strUnknown']					= "Unknown";

$GLOBALS['strWelcomeTo']				= "Welcome to";
$GLOBALS['strEnterUsername']			= "Enter your username and password to log in";

$GLOBALS['strBannerNetwork']			= "Banner network";
$GLOBALS['strMoreInformation']			= "More information...";
$GLOBALS['strChooseNetwork']			= "Choose the banner network you want to use";
$GLOBALS['strRichMedia']				= "Richmedia";
$GLOBALS['strTrackAdClicks']			= "Track AdClicks";
$GLOBALS['strYes']						= "Yes";
$GLOBALS['strNo']						= "No";
$GLOBALS['strUploadOrKeep']				= "Do you wish to keep your <br>existing image, or do you <br>want to upload another?";
$GLOBALS['strCheckSWF']					= "Check for hard-coded links inside the Flash file";
$GLOBALS['strURL2']						= "URL";
$GLOBALS['strTarget']					= "Target";
$GLOBALS['strConvert']					= "Convert";
$GLOBALS['strCancel']					= "Cancel";

$GLOBALS['strConvertSWFLinks']			= "Convert Flash links";
$GLOBALS['strConvertSWF']				= "<br>The Flash file you just uploaded contains hard-coded urls. phpAdsNew won't be ".
										  "able to track the number of AdClicks for this banner unless you convert these ".
										  "hard-coded urls. Below you will find a list of all urls inside the Flash file. ".
										  "If you want to convert the urls, simply click <b>Convert</b>, otherwise click ".
										  "<b>Cancel</b>.<br><br>".
										  "Please note: if you click <b>Convert</b> the Flash file ".
									  	  "you just uploaded will be physically altered. <br>Please keep a backup of the ".
										  "original file. Regardless of in which version this banner was created, the resulting ".
										  "file will need the Flash 4 player (or higher) to display correctly.<br><br>";

$GLOBALS['strSourceStats']				= "Source Stats";
$GLOBALS['strSelectSource']				= "Select the source you want to view:";

?>