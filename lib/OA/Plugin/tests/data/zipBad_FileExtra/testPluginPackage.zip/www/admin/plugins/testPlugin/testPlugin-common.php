<?php
require_once '../../../../init.php';
require_once '../../config.php';

require_once MAX_PATH . '/lib/OA/Admin/TemplatePlugin.php';

?>